"use client"

import { useState, useEffect, use } from "react"
import { Button } from "@/components/ui/button"
import { Printer, Download, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

interface Cotizacion {
  _id: string
  numero: string
  cliente: {
    id: string
    nombre: string
    email: string
    telefono: string
    direccion: string
    rtn?: string
  }
  vendedor: {
    id: string
    nombre: string
    email: string
  }
  items: Array<{
    tipo: string
    nombre: string
    descripcion: string
    cantidad: number
    precio_unitario: number
    precio_total: number
    dimensiones?: any
    especificaciones?: any
    grupoId?: string
    imagen?: any
    imagenUrl?: any
  }>
  grupos: Array<{
    id: string
    nombre: string
    descripcion: string
    imagen?: any
    imagenUrl?: any
  }>
  subtotal: number
  iva: number
  total: number
  descuento: number
  estado: string
  fechaCreacion: string
  fechaVencimiento: string
  notas?: string
  pagos_realizados?: number
  saldo_pendiente?: number
}

export default function ImprimirCotizacionPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const [cotizacion, setCotizacion] = useState<Cotizacion | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    cargarCotizacion()
  }, [resolvedParams.id])

  const cargarCotizacion = async () => {
    try {
      const response = await fetch(`/api/cotizaciones/${resolvedParams.id}`)
      if (response.ok) {
        const data = await response.json()
        setCotizacion(data.cotizacion)
      } else {
        toast.error("Error al cargar la cotización")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("Error de conexión")
    } finally {
      setLoading(false)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleDownloadPDF = async () => {
    try {
      const response = await fetch(`/api/cotizaciones/${resolvedParams.id}/pdf`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.style.display = "none"
        a.href = url
        a.download = `Cotizacion-${cotizacion?.numero}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        toast.success("PDF descargado exitosamente")
      } else {
        toast.error("Error al generar PDF")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("Error al descargar PDF")
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!cotizacion) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Cotización no encontrada</h2>
          <Button onClick={() => router.back()}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Barra de herramientas - Solo visible en pantalla */}
      <div className="bg-white shadow-sm border-b p-4 print:hidden">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleDownloadPDF}>
              <Download className="w-4 h-4 mr-2" />
              Descargar PDF
            </Button>
            <Button onClick={handlePrint}>
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>
          </div>
        </div>
      </div>

      {/* Contenido de la cotización */}
      <div className="max-w-4xl mx-auto p-6 print:p-0" id="cotizacion-content">
        <div className="bg-white rounded-lg shadow-lg border-4 border-blue-500 p-8 print:shadow-none print:border-2">
          {/* Encabezado Principal */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="flex items-center col-span-2">
              <div className="w-32 h-32 bg-gray-200 rounded-lg flex items-center justify-center mr-6">
                <span className="text-gray-500 text-xs">LOGO</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">ArquiAlum Honduras</h1>
                <p className="text-sm text-gray-600">Colonia Kennedy, Bloque M, Casa 2516</p>
                <p className="text-sm text-gray-600">Tegucigalpa, Honduras</p>
                <p className="text-sm text-gray-600">RTN: 08019016832627</p>
                <p className="text-sm text-gray-600">Tel: +504 9999-9999 / Email: info@arquialum.hn</p>
              </div>
            </div>
            <div className="text-right">
              <div className="bg-gray-100 p-4 rounded-lg">
                <h2 className="text-xl font-bold text-gray-800">Cotización</h2>
                <p className="text-sm text-gray-600">#{cotizacion.numero}</p>
                <p className="text-sm text-gray-600">
                  Fecha: {new Date(cotizacion.fechaCreacion).toLocaleDateString("es-HN")}
                </p>
                <p className="text-sm text-gray-600">
                  Válido hasta: {new Date(cotizacion.fechaVencimiento).toLocaleDateString("es-HN")}
                </p>
              </div>
            </div>
          </div>

          {/* Redes Sociales */}
          <div className="bg-gray-100 p-4 rounded-lg mb-6 text-center">
            <p className="text-sm">
              <span className="font-medium">Redes Sociales:</span>
              <span className="mx-2 text-blue-600">📘 ArquiAlumHonduras</span>
              <span className="mx-2">|</span>
              <span className="mx-2 text-black">🎵 @arqui.alum</span>
              <span className="mx-2">|</span>
              <span className="mx-2 text-pink-600">📷 arquialum.hn</span>
              <span className="mx-2">|</span>
              <span className="mx-2 text-blue-600">🌐 www.arquialumhn.com</span>
            </p>
          </div>

          {/* Separador */}
          <hr className="border-red-500 mb-6" />

          {/* Información del Cliente y Vendedor */}
          <div className="border-t border-b border-gray-300 py-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold text-gray-800 mb-2">INFORMACIÓN DEL CLIENTE</h3>
                <div className="text-sm space-y-1">
                  <p>
                    <span className="font-medium">Nombre:</span> {cotizacion.cliente.nombre}
                  </p>
                  <p>
                    <span className="font-medium">RTN:</span> {cotizacion.cliente.rtn || "N/A"}
                  </p>
                  <p>
                    <span className="font-medium">Teléfono:</span> {cotizacion.cliente.telefono || "N/A"}
                  </p>
                  <p>
                    <span className="font-medium">Dirección:</span> {cotizacion.cliente.direccion || "N/A"}
                  </p>
                </div>
              </div>
              <div>
                <h3 className="font-bold text-gray-800 mb-2">INFORMACIÓN DEL VENDEDOR</h3>
                <div className="text-sm space-y-1">
                  <p>
                    <span className="font-medium">Encargada:</span> María González
                  </p>
                  <p>
                    <span className="font-medium">Asesor de Venta:</span> {cotizacion.vendedor.nombre}
                  </p>
                  <p>
                    <span className="font-medium">Teléfono:</span> +504 9999-9999
                  </p>
                  <p>
                    <span className="font-medium">Email:</span> {cotizacion.vendedor.email}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Separador */}
          <hr className="border-blue-500 mb-6" />

          {/* Productos por Grupos */}
          <div className="mb-6">
            {cotizacion.grupos.map((grupo) => {
              const itemsDelGrupo = cotizacion.items.filter((item) => item.grupoId === grupo.id)
              if (itemsDelGrupo.length === 0) return null

              return (
                <div key={grupo.id} className="mb-8">
                  {/* Encabezado del Grupo */}
                  <div className="bg-gray-200 p-4 rounded-lg mb-4">
                    <div className="flex items-center justify-center">
                      {grupo.imagenUrl && (
                        <img
                          src={grupo.imagenUrl || "/placeholder.svg"}
                          alt={grupo.nombre}
                          className="max-w-xs h-32 object-cover rounded mr-4"
                        />
                      )}
                      <h5 className="font-bold text-lg text-gray-800">{grupo.nombre}</h5>
                    </div>
                  </div>

                  {/* Tabla de productos del grupo */}
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="border border-gray-300 px-4 py-2 text-left">Gráfico</th>
                          <th className="border border-gray-300 px-4 py-2 text-left">Producto y Detalles</th>
                          <th className="border border-gray-300 px-4 py-2 text-center">Precio Unitario</th>
                          <th className="border border-gray-300 px-4 py-2 text-center">Subtotal</th>
                        </tr>
                      </thead>
                      <tbody>
                        {itemsDelGrupo.map((item, index) => (
                          <tr key={index}>
                            <td className="border border-gray-300 p-4 text-center w-1/4">
                              {item.imagenUrl ? (
                                <img
                                  src={item.imagenUrl || "/placeholder.svg"}
                                  alt={item.nombre}
                                  className="max-w-full h-24 object-cover mx-auto"
                                />
                              ) : (
                                <div className="w-24 h-24 bg-gray-200 rounded mx-auto flex items-center justify-center">
                                  <span className="text-xs text-gray-500">Sin imagen</span>
                                </div>
                              )}
                            </td>
                            <td className="border border-gray-300 p-4">
                              <div className="space-y-1">
                                <p className="font-bold">{item.nombre}</p>
                                <p className="text-sm text-gray-600">{item.descripcion}</p>
                                {item.dimensiones && (
                                  <p className="text-sm">
                                    Dimensiones: {item.dimensiones.ancho || "N/A"} x {item.dimensiones.alto || "N/A"}
                                  </p>
                                )}
                                {item.especificaciones && (
                                  <div className="text-sm">
                                    {item.especificaciones.color && <p>Color: {item.especificaciones.color}</p>}
                                    {item.especificaciones.material && (
                                      <p>Material: {item.especificaciones.material}</p>
                                    )}
                                  </div>
                                )}
                                <p className="text-sm font-medium">Cantidad: {item.cantidad}</p>
                              </div>
                            </td>
                            <td className="border border-gray-300 p-4 text-center">
                              <span className="font-medium">L {item.precio_unitario.toLocaleString("es-HN")}</span>
                            </td>
                            <td className="border border-gray-300 p-4 text-center">
                              <span className="font-bold">L {item.precio_total.toLocaleString("es-HN")}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Resumen Financiero */}
          <div className="mb-8">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <tbody>
                  <tr>
                    <td colSpan={3} className="text-right border border-gray-300 py-2 px-4 font-medium">
                      Productos Cotizados
                    </td>
                    <td className="text-center border border-gray-300 py-2 px-4">
                      {cotizacion.items.reduce((sum, item) => sum + item.cantidad, 0)}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={3} className="text-right border border-gray-300 py-2 px-4 font-medium">
                      Subtotal
                    </td>
                    <td className="text-center border border-gray-300 py-2 px-4">
                      L {cotizacion.subtotal.toLocaleString("es-HN")}
                    </td>
                  </tr>
                  {cotizacion.descuento > 0 && (
                    <tr>
                      <td colSpan={3} className="text-right border border-gray-300 py-2 px-4 font-medium">
                        Descuento
                      </td>
                      <td className="text-center border border-gray-300 py-2 px-4 text-red-600">
                        -L {cotizacion.descuento.toLocaleString("es-HN")}
                      </td>
                    </tr>
                  )}
                  <tr>
                    <td colSpan={3} className="text-right border border-gray-300 py-2 px-4 font-medium">
                      IVA (15%)
                    </td>
                    <td className="text-center border border-gray-300 py-2 px-4">
                      L {cotizacion.iva.toLocaleString("es-HN")}
                    </td>
                  </tr>
                  <tr className="bg-gray-100">
                    <td colSpan={3} className="text-right border border-gray-300 py-3 px-4 font-bold text-lg">
                      TOTAL
                    </td>
                    <td className="text-center border border-gray-300 py-3 px-4 font-bold text-lg text-green-600">
                      L {cotizacion.total.toLocaleString("es-HN")}
                    </td>
                  </tr>
                  {cotizacion.pagos_realizados && cotizacion.pagos_realizados > 0 && (
                    <>
                      <tr>
                        <td colSpan={3} className="text-right border border-gray-300 py-2 px-4 font-medium">
                          Pagos Realizados
                        </td>
                        <td className="text-center border border-gray-300 py-2 px-4 text-green-600">
                          L {cotizacion.pagos_realizados.toLocaleString("es-HN")}
                        </td>
                      </tr>
                      <tr className="bg-yellow-50">
                        <td colSpan={3} className="text-right border border-gray-300 py-2 px-4 font-bold">
                          Saldo Pendiente
                        </td>
                        <td className="text-center border border-gray-300 py-2 px-4 font-bold text-orange-600">
                          L {(cotizacion.saldo_pendiente || 0).toLocaleString("es-HN")}
                        </td>
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Términos y Condiciones */}
          <div className="bg-gray-100 p-6 rounded-lg mb-8">
            <h4 className="text-lg font-bold text-center mb-4 text-gray-800">Términos y Condiciones</h4>

            <div className="space-y-4 text-sm">
              <div>
                <p className="font-bold text-gray-800">1. Condiciones de Pago</p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Anticipo: 70% - L {(cotizacion.total * 0.7).toLocaleString("es-HN")}</li>
                  <li>
                    Pago Restante: 30% el día de instalación - L {(cotizacion.total * 0.3).toLocaleString("es-HN")}
                  </li>
                </ul>
              </div>

              <div>
                <p className="font-bold text-gray-800">2. Tiempo de Entrega</p>
                <ul className="list-disc list-inside ml-4">
                  <li>Plazo: 15 días hábiles desde la confirmación del pedido.</li>
                </ul>
              </div>

              <div>
                <p className="font-bold text-gray-800">3. Garantía</p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Período de Garantía: 3 meses por fabricación.</li>
                  <li className="font-medium">Exclusiones:</li>
                </ul>
                <ol className="list-decimal list-inside ml-8 space-y-1">
                  <li>La garantía no incluye fracturas de vidrio por accidentes posteriores a la instalación.</li>
                  <li>Precio incluye traslado dentro del casco urbano; fuera de este se cobrará flete.</li>
                  <li>
                    La cotización no cubre la desinstalación de ventanas existentes; este servicio se cobrará aparte.
                  </li>
                  <li>
                    Arquialum no se hace responsable si los boquetes de puertas y ventanas se encuentran con descuadres
                    mayores a 5 mm o desplomes en la pared.
                  </li>
                </ol>
              </div>

              <div>
                <p className="font-bold text-gray-800">4. Otros</p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Sellado de puertas y ventanas por dentro y por fuera con silicona de alta calidad.</li>
                  <li>Todos los perfiles de PVC llevan refuerzo metálico.</li>
                  <li>Todas las puertas y ventanas llevan malla mosquitero.</li>
                </ul>
              </div>
            </div>

            <div className="text-center mt-6 space-y-2">
              <p className="font-semibold text-gray-800">
                Su preferencia nos motiva a seguir mejorando calidad. Estamos a su disposición para cualquier consulta o
                información adicional.
              </p>
              <p className="font-bold text-gray-800">Gracias por elegirnos.</p>
              <p className="text-sm">
                <span className="font-medium">Duración de la Cotización Aprobada:</span> 30 días
              </p>
            </div>
          </div>

          {/* Firmas */}
          <div className="flex justify-between mt-12">
            <div className="text-center">
              <div className="border-t border-gray-500 w-48 mx-auto mb-2"></div>
              <p className="text-sm font-medium">Firma del Cliente</p>
            </div>
            <div className="text-center">
              <div className="border-t border-gray-500 w-48 mx-auto mb-2"></div>
              <p className="text-sm font-medium">Firma del Vendedor</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
