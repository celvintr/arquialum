import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()

    const configuracion = await db.collection("configuraciones_mano_obra").findOne({ _id: new ObjectId(params.id) })

    if (!configuracion) {
      return NextResponse.json({ success: false, error: "Configuración no encontrada" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      configuracion,
    })
  } catch (error) {
    console.error("Error obteniendo configuración:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const body = await request.json()

    const configuracionActualizada = {
      ...body,
      actualizado_en: new Date(),
    }

    const resultado = await db
      .collection("configuraciones_mano_obra")
      .updateOne({ _id: new ObjectId(params.id) }, { $set: configuracionActualizada })

    if (resultado.matchedCount === 0) {
      return NextResponse.json({ success: false, error: "Configuración no encontrada" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      configuracion: configuracionActualizada,
    })
  } catch (error) {
    console.error("Error actualizando configuración:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()

    const resultado = await db.collection("configuraciones_mano_obra").deleteOne({ _id: new ObjectId(params.id) })

    if (resultado.deletedCount === 0) {
      return NextResponse.json({ success: false, error: "Configuración no encontrada" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      message: "Configuración eliminada exitosamente",
    })
  } catch (error) {
    console.error("Error eliminando configuración:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}
