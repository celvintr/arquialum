import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const body = await request.json()

    const result = await db.collection("reparaciones_definidas").updateOne(
      { _id: params.id },
      {
        $set: {
          ...body,
          updated_at: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Reparación no encontrada" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error actualizando reparación:", error)
    return NextResponse.json({ error: "Error al actualizar reparación" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()

    const result = await db.collection("reparaciones_definidas").deleteOne({ _id: params.id })

    if (result.deletedCount === 0) {
      return NextResponse.json({ error: "Reparación no encontrada" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error eliminando reparación:", error)
    return NextResponse.json({ error: "Error al eliminar reparación" }, { status: 500 })
  }
}
