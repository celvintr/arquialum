import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import puppeteer from "puppeteer"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()

    const factura = await db.collection("facturas").findOne({ _id: params.id })

    if (!factura) {
      return NextResponse.json({ success: false, error: "Factura no encontrada" }, { status: 404 })
    }

    // Generar HTML para el PDF de la factura
    const htmlContent = generateFacturaHTML(factura)

    // Configurar Puppeteer
    const browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    })

    const page = await browser.newPage()

    await page.setContent(htmlContent, {
      waitUntil: "networkidle0",
    })

    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: {
        top: "20mm",
        right: "15mm",
        bottom: "20mm",
        left: "15mm",
      },
      displayHeaderFooter: true,
      headerTemplate: `
        <div style="font-size: 10px; width: 100%; text-align: center; color: #666;">
          <span>ArquiAlum Honduras - Factura ${factura.numero}</span>
        </div>
      `,
      footerTemplate: `
        <div style="font-size: 10px; width: 100%; text-align: center; color: #666;">
          <span>Página <span class="pageNumber"></span> de <span class="totalPages"></span> - Generado el ${new Date().toLocaleDateString("es-HN")}</span>
        </div>
      `,
    })

    await browser.close()

    return new NextResponse(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="Factura-${factura.numero}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generando PDF de factura:", error)
    return NextResponse.json({ success: false, error: "Error generando PDF" }, { status: 500 })
  }
}

function generateFacturaHTML(factura: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Factura ${factura.numero}</title>
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Arial', sans-serif;
          font-size: 12px;
          line-height: 1.4;
          color: #333;
        }
        
        .container {
          max-width: 100%;
          margin: 0 auto;
          padding: 20px;
        }
        
        .header {
          border: 4px solid #059669;
          padding: 20px;
          margin-bottom: 20px;
        }
        
        .header-grid {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: 20px;
          align-items: start;
        }
        
        .company-info {
          display: flex;
          align-items: center;
          gap: 15px;
        }
        
        .logo-placeholder {
          width: 80px;
          height: 80px;
          background-color: #f3f4f6;
          border: 1px solid #d1d5db;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          color: #6b7280;
        }
        
        .company-details h1 {
          font-size: 18px;
          font-weight: bold;
          color: #1f2937;
          margin-bottom: 5px;
        }
        
        .company-details p {
          font-size: 10px;
          color: #6b7280;
          margin-bottom: 2px;
        }
        
        .factura-info {
          background-color: #f0fdf4;
          padding: 15px;
          border-radius: 8px;
          text-align: right;
          border: 2px solid #059669;
        }
        
        .factura-info h2 {
          font-size: 16px;
          font-weight: bold;
          margin-bottom: 5px;
          color: #059669;
        }
        
        .client-info {
          border: 1px solid #d1d5db;
          padding: 15px;
          margin-bottom: 20px;
          background-color: #f9fafb;
        }
        
        .client-info h3 {
          font-weight: bold;
          margin-bottom: 8px;
          font-size: 12px;
          color: #059669;
        }
        
        .items-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        
        .items-table th,
        .items-table td {
          border: 1px solid #d1d5db;
          padding: 8px;
          text-align: left;
        }
        
        .items-table th {
          background-color: #059669;
          color: white;
          font-weight: bold;
          font-size: 10px;
        }
        
        .items-table td {
          font-size: 10px;
        }
        
        .totals-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        
        .totals-table td {
          border: 1px solid #d1d5db;
          padding: 8px;
          font-size: 11px;
        }
        
        .total-row {
          background-color: #f0fdf4;
          font-weight: bold;
          font-size: 12px;
        }
        
        .total-amount {
          color: #059669;
          font-weight: bold;
          font-size: 14px;
        }
        
        .payment-info {
          background-color: #f0f9ff;
          border: 1px solid #0ea5e9;
          padding: 15px;
          margin-bottom: 20px;
          border-radius: 8px;
        }
        
        .payment-info h4 {
          color: #0ea5e9;
          font-weight: bold;
          margin-bottom: 8px;
        }
        
        .footer-info {
          background-color: #f3f4f6;
          padding: 15px;
          text-align: center;
          font-size: 10px;
          border-radius: 8px;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="container">
        <!-- Header -->
        <div class="header">
          <div class="header-grid">
            <div class="company-info">
              <div class="logo-placeholder">LOGO</div>
              <div class="company-details">
                <h1>ArquiAlum Honduras</h1>
                <p>Colonia Kennedy, Bloque M, Casa 2516</p>
                <p>Tegucigalpa, Honduras</p>
                <p>RTN: 08019016832627</p>
                <p>Tel: +504 9999-9999 / Email: info@arquialum.hn</p>
              </div>
            </div>
            <div class="factura-info">
              <h2>FACTURA</h2>
              <p><strong>#${factura.numero}</strong></p>
              <p>Serie: ${factura.serie}</p>
              <p>Fecha: ${new Date(factura.fecha_emision).toLocaleDateString("es-HN")}</p>
              <p>Vence: ${new Date(factura.fecha_vencimiento).toLocaleDateString("es-HN")}</p>
            </div>
          </div>
        </div>

        <!-- Información del Cliente -->
        <div class="client-info">
          <h3>FACTURAR A:</h3>
          <p><strong>Cliente:</strong> ${factura.cliente.nombre}</p>
          <p><strong>RTN:</strong> ${factura.cliente.rtn || "N/A"}</p>
          <p><strong>Dirección:</strong> ${factura.cliente.direccion || "N/A"}</p>
          <p><strong>Teléfono:</strong> ${factura.cliente.telefono || "N/A"}</p>
          ${factura.numero_orden ? `<p><strong>Orden de Trabajo:</strong> ${factura.numero_orden}</p>` : ""}
        </div>

        <!-- Items de la Factura -->
        <table class="items-table">
          <thead>
            <tr>
              <th style="width: 10%;">Cant.</th>
              <th style="width: 50%;">Descripción</th>
              <th style="width: 15%;">Precio Unit.</th>
              <th style="width: 10%;">Desc.</th>
              <th style="width: 15%;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${factura.items
              .map(
                (item: any) => `
              <tr>
                <td class="text-center">${item.cantidad || 1}</td>
                <td>${item.descripcion}</td>
                <td class="text-right">L ${item.precio_unitario.toLocaleString("es-HN")}</td>
                <td class="text-right">L ${item.descuento.toLocaleString("es-HN")}</td>
                <td class="text-right">L ${item.total.toLocaleString("es-HN")}</td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
        </table>

        <!-- Totales -->
        <table class="totals-table">
          <tbody>
            <tr>
              <td colspan="4" class="text-right"><strong>Subtotal:</strong></td>
              <td class="text-right">L ${factura.subtotal.toLocaleString("es-HN")}</td>
            </tr>
            ${
              factura.descuento_global > 0
                ? `
              <tr>
                <td colspan="4" class="text-right"><strong>Descuento:</strong></td>
                <td class="text-right" style="color: #dc2626;">-L ${factura.descuento_global.toLocaleString("es-HN")}</td>
              </tr>
            `
                : ""
            }
            <tr>
              <td colspan="4" class="text-right"><strong>IVA (15%):</strong></td>
              <td class="text-right">L ${factura.impuesto_total.toLocaleString("es-HN")}</td>
            </tr>
            <tr class="total-row">
              <td colspan="4" class="text-right"><strong>TOTAL A PAGAR:</strong></td>
              <td class="text-right total-amount">L ${factura.total.toLocaleString("es-HN")}</td>
            </tr>
            ${
              factura.monto_pagado > 0
                ? `
              <tr>
                <td colspan="4" class="text-right"><strong>Monto Pagado:</strong></td>
                <td class="text-right" style="color: #059669;">L ${factura.monto_pagado.toLocaleString("es-HN")}</td>
              </tr>
              <tr style="background-color: #fef3c7;">
                <td colspan="4" class="text-right"><strong>Saldo Pendiente:</strong></td>
                <td class="text-right" style="color: #d97706; font-weight: bold;">L ${(factura.total - factura.monto_pagado).toLocaleString("es-HN")}</td>
              </tr>
            `
                : ""
            }
          </tbody>
        </table>

        <!-- Información de Pago -->
        ${
          factura.monto_pagado > 0
            ? `
          <div class="payment-info">
            <h4>INFORMACIÓN DE PAGO</h4>
            <p><strong>Tipo de Pago:</strong> ${factura.tipo_pago === "completo" ? "Pago Completo" : "Abono Parcial"}</p>
            <p><strong>Monto Pagado:</strong> L ${factura.monto_pagado.toLocaleString("es-HN")}</p>
            <p><strong>Fecha de Pago:</strong> ${new Date(factura.fecha_emision).toLocaleDateString("es-HN")}</p>
            ${factura.notas ? `<p><strong>Notas:</strong> ${factura.notas}</p>` : ""}
          </div>
        `
            : ""
        }

        <!-- Footer -->
        <div class="footer-info">
          <p><strong>¡Gracias por su preferencia!</strong></p>
          <p>Esta factura fue generada electrónicamente y es válida sin firma ni sello.</p>
          <p>Para consultas: info@arquialum.hn | +504 9999-9999</p>
        </div>
      </div>
    </body>
    </html>
  `
}
