import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import dbConnect from "@/lib/mongodb"
import Cotizacion from "@/lib/models/Cotizacion"
import { calcularTotalCotizacion, generarNumeroCotizacion } from "@/lib/utils/formula-calculator"

export async function GET(request: NextRequest) {
  try {
    console.log("🔍 API Cotizaciones - GET iniciado")
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    await dbConnect()

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const estado = searchParams.get("estado")
    const clienteId = searchParams.get("cliente")

    const query: any = {}

    // Filtrar por vendedor si no es admin
    if (session.user.role !== "admin") {
      query["vendedor.id"] = session.user.id
    }

    if (estado) {
      query.estado = estado
    }

    if (clienteId) {
      query["cliente.id"] = clienteId
    }

    const skip = (page - 1) * limit

    console.log("📊 Query cotizaciones:", query)

    const [cotizaciones, total] = await Promise.all([
      Cotizacion.find(query).skip(skip).limit(limit).sort({ createdAt: -1 }),
      Cotizacion.countDocuments(query),
    ])

    console.log(`✅ Cotizaciones encontradas: ${cotizaciones.length}/${total}`)

    return NextResponse.json({
      cotizaciones,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("❌ Error fetching cotizaciones:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log("➕ API Cotizaciones - POST iniciado")
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    await dbConnect()

    const data = await request.json()
    console.log("📝 Datos de la cotización:", data)

    // Validar que tenemos cliente
    if (!data.cliente_id) {
      return NextResponse.json({ error: "Cliente es requerido" }, { status: 400 })
    }

    // Obtener información del cliente desde la API
    let clienteInfo = null
    try {
      const clienteResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/clientes/${data.cliente_id}`)
      if (clienteResponse.ok) {
        const clienteData = await clienteResponse.json()
        clienteInfo = clienteData.cliente
      }
    } catch (error) {
      console.log("⚠️ No se pudo obtener info del cliente:", error)
    }

    // Generar número de cotización
    const numero = generarNumeroCotizacion()

    // Calcular totales usando la función corregida
    const totales = calcularTotalCotizacion(data.items || [])

    // Crear fecha de vencimiento (30 días desde hoy)
    const fechaVencimiento = new Date()
    fechaVencimiento.setDate(fechaVencimiento.getDate() + 30)

    // Limpiar los items para evitar problemas de tipo
    const itemsLimpios = (data.items || []).map((item) => {
      // Convertir campos de objeto vacío a null o string según corresponda
      return {
        ...item,
        imagen: item.imagen || null,
        imagenUrl: item.imagenUrl || null,
        // Asegurarse de que otros campos sean del tipo correcto
        materiales: Array.isArray(item.materiales) ? item.materiales : [],
        cantidad: Number(item.cantidad || 1),
        precio_unitario: Number(item.precio_unitario || 0),
        precio_total: Number(item.precio_total || 0),
      }
    })

    const cotizacionData = {
      numero,
      cliente_id: data.cliente_id,
      cliente: clienteInfo
        ? {
            id: String(clienteInfo._id || clienteInfo.id || data.cliente_id),
            nombre: clienteInfo.nombre || "Cliente",
            email: clienteInfo.email || "",
            telefono: clienteInfo.telefono || "",
            direccion: clienteInfo.direccion || "",
          }
        : {
            id: String(data.cliente_id),
            nombre: "Cliente",
            email: "",
            telefono: "",
            direccion: "",
          },
      vendedor: {
        id: String(session.user.id),
        nombre: session.user.name || "Vendedor",
        email: session.user.email || "",
      },
      items: itemsLimpios,
      grupos: data.grupos || [],
      subtotal: totales.subtotal,
      iva: totales.iva,
      total: totales.total,
      tipo: data.tipo || "mixta",
      estado: data.estado || "borrador",
      moneda: "HNL", // Lempiras
      notas: data.notas || "",
      fechaVencimiento: fechaVencimiento,
      fechaCreacion: new Date(),
    }

    console.log("📋 Datos finales para crear cotización:", cotizacionData)

    const cotizacion = new Cotizacion(cotizacionData)
    await cotizacion.save()

    console.log("✅ Cotización creada:", cotizacion.numero)

    return NextResponse.json(
      {
        success: true,
        cotizacion: {
          _id: cotizacion._id, // Asegurarse de retornar el _id correcto
          id: cotizacion._id,
          numero: cotizacion.numero,
          total: cotizacion.total,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("❌ Error creating cotizacion:", error)
    return NextResponse.json(
      {
        error: "Error al crear cotización",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
