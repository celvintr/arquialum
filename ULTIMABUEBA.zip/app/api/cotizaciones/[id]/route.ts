import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

// GET - Obtener una cotización específica
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const resolvedParams = await params
    const { db } = await connectToDatabase()

    // Convertir string a ObjectId
    const cotizacionId = new ObjectId(resolvedParams.id)
    const cotizacion = await db.collection("cotizacions").findOne({ _id: cotizacionId })

    if (!cotizacion) {
      return NextResponse.json({ success: false, error: "Cotización no encontrada" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      cotizacion,
    })
  } catch (error) {
    console.error("Error obteniendo cotización:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}

// PUT - Actualizar una cotización
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const resolvedParams = await params
    const { db } = await connectToDatabase()
    const body = await request.json()

    // Convertir string a ObjectId
    const cotizacionId = new ObjectId(resolvedParams.id)

    const cotizacionActualizada = await db.collection("cotizacions").findOneAndUpdate(
      { _id: cotizacionId },
      {
        $set: {
          ...body,
          fechaActualizacion: new Date(),
        },
      },
      { returnDocument: "after" },
    )

    if (!cotizacionActualizada) {
      return NextResponse.json({ success: false, error: "Cotización no encontrada" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      cotizacion: cotizacionActualizada,
      message: "Cotización actualizada exitosamente",
    })
  } catch (error) {
    console.error("Error actualizando cotización:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}

// DELETE - Eliminar una cotización con validaciones
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const resolvedParams = await params
    const { db } = await connectToDatabase()

    console.log("🗑️ Intentando eliminar cotización:", resolvedParams.id)

    // Convertir string a ObjectId
    const cotizacionId = new ObjectId(resolvedParams.id)

    // Verificar si la cotización existe
    const cotizacion = await db.collection("cotizacions").findOne({ _id: cotizacionId })

    if (!cotizacion) {
      return NextResponse.json({ success: false, error: "Cotización no encontrada" }, { status: 404 })
    }

    // Verificar si tiene órdenes de trabajo
    const ordenes = await db.collection("ordenes-trabajo").find({ cotizacion_id: resolvedParams.id }).toArray()

    if (ordenes.length > 0) {
      console.log("❌ No se puede eliminar - tiene órdenes de trabajo:", ordenes.length)
      return NextResponse.json(
        {
          success: false,
          error: "No se puede eliminar una cotización que ya tiene órdenes de trabajo asociadas",
        },
        { status: 400 },
      )
    }

    // Verificar si tiene pagos
    const pagos = await db
      .collection("pagos")
      .find({
        $or: [
          { cotizacion_id: resolvedParams.id },
          { factura_id: { $regex: resolvedParams.id } },
          { orden_trabajo_id: { $regex: resolvedParams.id } },
        ],
      })
      .toArray()

    if (pagos.length > 0) {
      console.log("❌ No se puede eliminar - tiene pagos:", pagos.length)
      return NextResponse.json(
        {
          success: false,
          error: "No se puede eliminar una cotización que ya tiene pagos registrados",
        },
        { status: 400 },
      )
    }

    // Verificar estado - no eliminar si está aprobada (a menos que no tenga órdenes ni pagos)
    if (cotizacion.estado === "aprobada") {
      console.log("⚠️ Advertencia - eliminando cotización aprobada sin órdenes ni pagos")
    }

    // Si pasa todas las validaciones, eliminar
    const resultado = await db.collection("cotizacions").deleteOne({ _id: cotizacionId })

    if (resultado.deletedCount === 0) {
      return NextResponse.json({ success: false, error: "No se pudo eliminar la cotización" }, { status: 500 })
    }

    console.log("✅ Cotización eliminada exitosamente:", resolvedParams.id)

    return NextResponse.json({
      success: true,
      message: "Cotización eliminada exitosamente",
    })
  } catch (error) {
    console.error("Error eliminando cotización:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}
