import { NextResponse, type NextRequest } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const resolvedParams = await params
    const { db } = await connectToDatabase()

    console.log("🔍 Consultando estado de pago para cotización:", resolvedParams.id)

    // Convertir string a ObjectId para MongoDB
    let cotizacionId
    try {
      cotizacionId = new ObjectId(resolvedParams.id)
    } catch (error) {
      console.log("❌ ID inválido:", resolvedParams.id)
      return NextResponse.json({ success: false, error: "ID de cotización inválido" }, { status: 400 })
    }

    // Obtener la cotización usando ObjectId
    const cotizacion = await db.collection("cotizacions").findOne({ _id: cotizacionId })

    if (!cotizacion) {
      console.log("❌ Cotización no encontrada:", resolvedParams.id)
      return NextResponse.json({ success: false, error: "Cotización no encontrada" }, { status: 404 })
    }

    console.log("✅ Cotización encontrada:", cotizacion.numero, "Total:", cotizacion.total)

    // Obtener todos los pagos relacionados con esta cotización (usando string ID para pagos)
    const pagos = await db
      .collection("pagos")
      .find({
        $or: [
          { cotizacion_id: resolvedParams.id },
          { factura_id: { $regex: resolvedParams.id } },
          { orden_trabajo_id: { $regex: resolvedParams.id } },
        ],
      })
      .toArray()

    console.log("💳 Pagos encontrados:", pagos.length)

    // Calcular totales de pagos
    const totalPagado = pagos.reduce((sum, pago) => {
      const monto = pago.monto || 0
      console.log("💰 Pago:", pago.numero, "Monto:", monto, "Estado:", pago.estado)
      return sum + (pago.estado === "confirmado" ? monto : 0)
    }, 0)

    const saldoPendiente = Math.max(0, (cotizacion.total || 0) - totalPagado)
    const porcentajePagado = cotizacion.total > 0 ? (totalPagado / cotizacion.total) * 100 : 0

    console.log("📊 Resumen - Total:", cotizacion.total, "Pagado:", totalPagado, "Pendiente:", saldoPendiente)

    // Obtener órdenes de trabajo relacionadas
    const ordenes = await db.collection("ordenes-trabajo").find({ cotizacion_id: resolvedParams.id }).toArray()

    const estadoPago = {
      total_cotizacion: cotizacion.total || 0,
      total_pagado: totalPagado,
      saldo_pendiente: saldoPendiente,
      porcentaje_pagado: porcentajePagado,
      pagos: pagos,
      ordenes: ordenes,
      puede_pagar: ordenes.some((orden) => orden.estado === "en_proceso" || orden.estado === "completada"),
    }

    return NextResponse.json({
      success: true,
      estado_pago: estadoPago,
    })
  } catch (error) {
    console.error("❌ Error obteniendo estado de pago:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = await params
  try {
    const cotizacionId = resolvedParams.id
    const { estadoPago } = await request.json()

    if (!estadoPago) {
      return NextResponse.json({ error: "El estado de pago es requerido" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    // Convertir a ObjectId
    const objectId = new ObjectId(cotizacionId)

    const updatedCotizacion = await db
      .collection("cotizacions")
      .updateOne({ _id: objectId }, { $set: { estadoPago: estadoPago } })

    if (!updatedCotizacion.modifiedCount) {
      return NextResponse.json({ error: "Cotización no encontrada o no se pudo actualizar" }, { status: 404 })
    }

    const cotizacion = await db.collection("cotizacions").findOne({ _id: objectId })

    return NextResponse.json(cotizacion, { status: 200 })
  } catch (error) {
    console.error("Error actualizando el estado de pago:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
