import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET() {
  try {
    const { db } = await connectToDatabase()

    // Obtener órdenes reales de la base de datos
    const ordenes = await db.collection("ordenes-trabajo").find({}).sort({ created_at: -1 }).toArray()

    // Si no hay órdenes, devolver array vacío
    if (ordenes.length === 0) {
      return NextResponse.json({
        success: true,
        ordenes: [],
        message: "No hay órdenes de trabajo registradas",
      })
    }

    return NextResponse.json({
      success: true,
      ordenes: ordenes,
    })
  } catch (error) {
    console.error("Error obteniendo órdenes:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error interno del servidor",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { db } = await connectToDatabase()
    const body = await request.json()

    console.log("📝 Creando orden de trabajo:", body)

    if (!body.cotizacion_id) {
      return NextResponse.json(
        {
          success: false,
          error: "ID de cotización es requerido",
        },
        { status: 400 },
      )
    }

    // Verificar si ya existe una orden para esta cotización
    const ordenExistente = await db.collection("ordenes-trabajo").findOne({
      cotizacion_id: body.cotizacion_id,
    })

    if (ordenExistente) {
      return NextResponse.json(
        {
          success: false,
          error: "Ya existe una orden de trabajo para esta cotización",
          orden_existente: ordenExistente.numero,
        },
        { status: 400 },
      )
    }

    // Obtener datos completos de la cotización desde la base de datos
    let cotizacionData = null
    try {
      // Primero intentamos con ObjectId
      try {
        cotizacionData = await db.collection("cotizacions").findOne({
          _id: new ObjectId(body.cotizacion_id),
        })
      } catch (err) {
        // Si falla, intentamos con el ID como string
        cotizacionData = await db.collection("cotizacions").findOne({
          _id: body.cotizacion_id,
        })
      }

      console.log("📋 Datos de cotización obtenidos:", cotizacionData)

      if (!cotizacionData) {
        console.log("⚠️ Cotización no encontrada con ID:", body.cotizacion_id)
        // Intentar buscar por otros campos
        cotizacionData = await db.collection("cotizacions").findOne({
          numero: body.cotizacion_numero,
        })

        if (!cotizacionData) {
          return NextResponse.json(
            {
              success: false,
              error: "Cotización no encontrada",
              details: `No se encontró cotización con ID: ${body.cotizacion_id} o número: ${body.cotizacion_numero}`,
            },
            { status: 404 },
          )
        }
      }
    } catch (error) {
      console.log("⚠️ Error obteniendo cotización:", error)
      return NextResponse.json(
        {
          success: false,
          error: "Error al obtener datos de la cotización",
          details: error.message,
        },
        { status: 500 },
      )
    }

    // Generar número de orden único
    const numeroOrden = `OT-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`

    // Calcular costos basados en la cotización real
    const totalCotizacion = cotizacionData.total || 0
    const subtotalCotizacion = cotizacionData.subtotal || 0

    const nuevaOrden = {
      numero: numeroOrden,
      cotizacion_id: body.cotizacion_id,
      cotizacion_numero: cotizacionData.numero,
      cliente_id: cotizacionData.cliente_id,
      cliente_nombre: cotizacionData.cliente?.nombre || "Cliente sin nombre",
      cliente_email: cotizacionData.cliente?.email || "",
      cliente_telefono: cotizacionData.cliente?.telefono || "",
      estado: "pendiente",
      fecha_inicio: new Date(),
      fecha_estimada_fin: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // +15 días
      costos_estimados: {
        materiales: Math.round(subtotalCotizacion * 0.6), // 60% materiales
        mano_obra: Math.round(subtotalCotizacion * 0.3), // 30% mano de obra
        otros: Math.round(subtotalCotizacion * 0.1), // 10% otros
        total: totalCotizacion,
      },
      costos_reales: {
        materiales: 0,
        mano_obra: 0,
        otros: 0,
        total: 0,
      },
      progreso_porcentaje: 0,
      materiales_utilizados: [],
      mano_obra_registrada: [],
      items_cotizacion: cotizacionData.items || [],
      grupos_cotizacion: cotizacionData.grupos || [],
      notas: `Orden creada desde cotización ${cotizacionData.numero}`,
      created_at: new Date(),
    }

    // Insertar en la base de datos
    const result = await db.collection("ordenes-trabajo").insertOne(nuevaOrden)

    console.log("✅ Orden de trabajo creada con ID:", result.insertedId)

    return NextResponse.json({
      success: true,
      orden: {
        _id: result.insertedId,
        ...nuevaOrden,
      },
      message: "Orden de trabajo creada exitosamente",
    })
  } catch (error) {
    console.error("❌ Error creando orden:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error interno del servidor",
        message: error.message,
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { db } = await connectToDatabase()
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json(
        {
          success: false,
          error: "ID de orden es requerido",
        },
        { status: 400 },
      )
    }

    const result = await db.collection("ordenes-trabajo").deleteOne({
      _id: new ObjectId(id),
    })

    if (result.deletedCount === 0) {
      return NextResponse.json(
        {
          success: false,
          error: "Orden no encontrada",
        },
        { status: 404 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Orden eliminada exitosamente",
    })
  } catch (error) {
    console.error("Error eliminando orden:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error interno del servidor",
      },
      { status: 500 },
    )
  }
}
