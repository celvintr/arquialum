import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log("🔍 API Cotizar Producto - POST iniciado")

    const { db } = await connectToDatabase()
    const body = await request.json()
    const { dimensiones, proveedor_id, variantes_seleccionadas, cantidad = 1 } = body

    console.log("📊 Datos recibidos:", { dimensiones, proveedor_id, variantes_seleccionadas, cantidad })

    // 1. Obtener producto y sus fórmulas
    const producto = await db.collection("productos").findOne({ _id: params.id })
    if (!producto) {
      return NextResponse.json({ error: "Producto no encontrado" }, { status: 404 })
    }

    const formulas = await db
      .collection("productomaterialformulas")
      .find({ producto_id: params.id, activo: true })
      .sort({ orden: 1 })
      .toArray()

    // 2. Calcular materiales necesarios
    const materialesCalculados = []
    let costoTotal = 0

    for (const formula of formulas) {
      // Obtener material base
      const materialBase = await db.collection("materialesbase").findOne({ _id: formula.material_base_id })

      // Obtener precio del proveedor seleccionado
      const materialProveedor = await db.collection("materialesproveedores").findOne({
        material_base_id: formula.material_base_id,
        proveedor_id: proveedor_id,
        activo: true,
      })

      if (!materialProveedor) {
        console.warn(`⚠️ Material ${materialBase?.nombre} no disponible con proveedor ${proveedor_id}`)
        continue
      }

      // Calcular cantidad usando la fórmula
      const cantidadCalculada = evaluarFormula(formula.formula, dimensiones)

      // Obtener costo adicional por variantes
      let costoAdicionalVariantes = 0
      if (variantes_seleccionadas) {
        for (const [tipoVariante, varianteId] of Object.entries(variantes_seleccionadas)) {
          if (varianteId) {
            const variante = await db.collection("variantesmateriales").findOne({ _id: varianteId })
            if (variante && variante.material_base_id === formula.material_base_id) {
              costoAdicionalVariantes += variante.costo_adicional
            }
          }
        }
      }

      // Calcular costo total del material
      const precioUnitario = materialProveedor.precio_final + costoAdicionalVariantes
      const costoMaterial = cantidadCalculada * precioUnitario * cantidad

      materialesCalculados.push({
        material_base_id: formula.material_base_id,
        material_nombre: materialBase.nombre,
        proveedor_nombre: materialProveedor.nombre_proveedor,
        codigo_proveedor: materialProveedor.codigo_proveedor,
        cantidad_calculada: cantidadCalculada,
        cantidad_total: cantidadCalculada * cantidad,
        precio_unitario: precioUnitario,
        costo_total: costoMaterial,
        unidad_medida: materialBase.unidad_medida_produccion,
        variantes_aplicadas: costoAdicionalVariantes,
      })

      costoTotal += costoMaterial
    }

    // 3. Aplicar margen de ganancia (30% por defecto)
    const margenGanancia = 0.3
    const precioVenta = costoTotal * (1 + margenGanancia)

    const resultado = {
      producto: {
        id: producto._id,
        nombre: producto.nombre,
      },
      dimensiones,
      cantidad,
      materiales: materialesCalculados,
      costos: {
        materiales: costoTotal,
        margen_ganancia: costoTotal * margenGanancia,
        precio_unitario: precioVenta / cantidad,
        precio_total: precioVenta,
      },
      proveedor_seleccionado: proveedor_id,
      variantes_seleccionadas,
    }

    console.log("✅ Cotización calculada:", resultado)

    return NextResponse.json({ resultado })
  } catch (error) {
    console.error("❌ Error al cotizar producto:", error)
    return NextResponse.json({ error: "Error al calcular cotización" }, { status: 500 })
  }
}

// Función para evaluar fórmulas
function evaluarFormula(formula: string, dimensiones: any): number {
  try {
    // Reemplazar variables en la fórmula
    const formulaCalculada = formula
      .replace(/ancho/gi, (dimensiones.ancho || 0).toString())
      .replace(/alto/gi, (dimensiones.alto || 0).toString())
      .replace(/divisionHorizontal/gi, (dimensiones.divisionHorizontal || 0).toString())
      .replace(/divisionVertical/gi, (dimensiones.divisionVertical || 0).toString())

    // Evaluar de forma segura
    const result = Function(`"use strict"; return (${formulaCalculada})`)()
    return isNaN(result) ? 0 : Number(result.toFixed(4))
  } catch (error) {
    console.error("Error evaluando fórmula:", error)
    return 0
  }
}
