import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const id = params.id

    console.log("🔍 GET producto por ID:", id)

    // Buscar el producto por ID
    const producto = await db.collection("productos").findOne({ _id: id })

    if (!producto) {
      console.log("❌ Producto no encontrado:", id)
      return NextResponse.json({ error: "Producto no encontrado" }, { status: 404 })
    }

    console.log("✅ Producto encontrado:", producto.nombre)
    return NextResponse.json({ success: true, producto })
  } catch (error) {
    console.error("❌ Error obteniendo producto:", error)
    return NextResponse.json({ error: "Error interno del servidor", details: error.message }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log("🔄 PUT /api/productos/[id] - Iniciando actualización")
    console.log("ID recibido:", params.id)

    const { db } = await connectToDatabase()
    const formData = await request.formData()

    // Extraer datos del FormData
    const nombre = formData.get("nombre") as string
    const identificador = formData.get("identificador") as string
    const descripcion = formData.get("descripcion") as string
    const tipo_producto_id = formData.get("tipo_producto_id") as string
    const categoria = formData.get("categoria") as string
    const precio_base = Number.parseFloat(formData.get("precio_base") as string) || 0
    const estado = formData.get("estado") === "true"
    const svg = formData.get("svg") as string
    const imagenActual = formData.get("imagenActual") as string
    const imagen = formData.get("imagen") as File

    console.log("📝 Datos recibidos:", {
      nombre,
      identificador,
      tipo_producto_id,
      categoria,
      precio_base,
      estado,
      tieneImagen: !!imagen,
      imagenActual,
    })

    // Validar campos requeridos
    if (!nombre?.trim()) {
      return NextResponse.json({ error: "El nombre es requerido" }, { status: 400 })
    }

    if (!tipo_producto_id) {
      return NextResponse.json({ error: "El tipo de producto es requerido" }, { status: 400 })
    }

    // Validar que el producto existe
    const productoExistente = await db.collection("productos").findOne({
      _id: params.id,
    })

    if (!productoExistente) {
      console.log("❌ Producto no encontrado para actualizar:", params.id)
      return NextResponse.json({ error: "Producto no encontrado" }, { status: 404 })
    }

    console.log("✅ Producto encontrado para actualizar:", productoExistente.nombre)

    // Preparar datos para actualizar
    const updateData: any = {
      nombre: nombre.trim(),
      identificador: identificador?.trim() || "",
      descripcion: descripcion?.trim() || "",
      tipo_producto_id: tipo_producto_id,
      categoria: categoria || "",
      precio_base: precio_base,
      estado: estado,
      svg: svg?.trim() || "",
      updatedAt: new Date(),
    }

    // Manejar imagen
    let rutaImagen = imagenActual || ""

    if (imagen && imagen.size > 0) {
      try {
        // Validar tamaño (5MB máximo)
        if (imagen.size > 5 * 1024 * 1024) {
          return NextResponse.json({ error: "La imagen no puede ser mayor a 5MB" }, { status: 400 })
        }

        // Validar tipo
        if (!imagen.type.startsWith("image/")) {
          return NextResponse.json({ error: "Solo se permiten archivos de imagen" }, { status: 400 })
        }

        // En un entorno real, aquí subirías la imagen a un servicio como AWS S3, Cloudinary, etc.
        // Por ahora, simularemos que se guarda correctamente
        const timestamp = Date.now()
        const extension = imagen.name.split(".").pop() || "jpg"
        rutaImagen = `/uploads/productos/${timestamp}-${params.id}.${extension}`

        console.log("📷 Nueva imagen procesada:", rutaImagen)

        // TODO: Implementar subida real de imagen
        // const buffer = await imagen.arrayBuffer()
        // await uploadToStorage(buffer, rutaImagen)
      } catch (error) {
        console.error("❌ Error procesando imagen:", error)
        return NextResponse.json({ error: "Error procesando la imagen" }, { status: 500 })
      }
    }

    updateData.imagen = rutaImagen

    console.log("💾 Actualizando en base de datos:", updateData)

    // Actualizar producto
    const result = await db.collection("productos").updateOne({ _id: params.id }, { $set: updateData })

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Producto no encontrado" }, { status: 404 })
    }

    console.log("✅ Producto actualizado exitosamente")

    // Obtener el producto actualizado con datos poblados
    const productoActualizado = await db
      .collection("productos")
      .aggregate([
        { $match: { _id: params.id } },
        {
          $lookup: {
            from: "tipos_producto", // Nombre correcto de la colección
            localField: "tipo_producto_id",
            foreignField: "_id",
            as: "tipoProducto",
          },
        },
        {
          $lookup: {
            from: "proveedores", // También incluir proveedor si existe
            localField: "proveedor_id",
            foreignField: "_id",
            as: "proveedor",
          },
        },
        {
          $addFields: {
            tipoProducto: { $arrayElemAt: ["$tipoProducto", 0] },
            proveedor: { $arrayElemAt: ["$proveedor", 0] },
          },
        },
      ])
      .toArray()

    console.log("📦 Producto actualizado con relaciones:", productoActualizado[0])

    return NextResponse.json({
      success: true,
      message: "Producto actualizado exitosamente",
      producto: productoActualizado[0] || updateData,
    })
  } catch (error) {
    console.error("❌ Error actualizando producto:", error)
    return NextResponse.json(
      {
        error: "Error interno del servidor",
        details: error.message,
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log("🗑️ DELETE /api/productos/[id] - Eliminando producto:", params.id)

    const { db } = await connectToDatabase()

    // Verificar que el producto existe
    const producto = await db.collection("productos").findOne({
      _id: params.id,
    })

    if (!producto) {
      console.log("❌ Producto no encontrado para eliminar:", params.id)
      return NextResponse.json({ error: "Producto no encontrado" }, { status: 404 })
    }

    console.log("✅ Producto encontrado para eliminar:", producto.nombre)

    // Eliminar producto
    const result = await db.collection("productos").deleteOne({
      _id: params.id,
    })

    if (result.deletedCount === 0) {
      console.log("❌ No se pudo eliminar el producto:", params.id)
      return NextResponse.json({ error: "No se pudo eliminar el producto" }, { status: 500 })
    }

    console.log("✅ Producto eliminado exitosamente")

    return NextResponse.json({
      success: true,
      message: "Producto eliminado exitosamente",
    })
  } catch (error) {
    console.error("❌ Error eliminando producto:", error)
    return NextResponse.json(
      {
        error: "Error interno del servidor",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
