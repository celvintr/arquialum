"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Package, Settings, CheckCircle, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface CrearProductoModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export default function CrearProductoModal({ isOpen, onClose, onSuccess }: CrearProductoModalProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [tiposProducto, setTiposProducto] = useState<any[]>([])

  const [formData, setFormData] = useState({
    nombre: "",
    identificador: "",
    descripcion: "",
    tipo_producto_id: "",
    categoria: "",
    precio_base: 0,
  })

  useEffect(() => {
    if (isOpen) {
      cargarTiposProducto()
    }
  }, [isOpen])

  const cargarTiposProducto = async () => {
    try {
      const response = await fetch("/api/tipos-producto")
      const data = await response.json()
      if (data.success) {
        setTiposProducto(data.tipos || [])
      }
    } catch (error) {
      console.error("Error cargando tipos de producto:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los tipos de producto",
        variant: "destructive",
      })
    }
  }

  const handleSubmit = async () => {
    try {
      setLoading(true)

      if (!formData.nombre || !formData.tipo_producto_id) {
        toast({
          title: "Campos requeridos",
          description: "Completa nombre y tipo de producto",
          variant: "destructive",
        })
        return
      }

      const response = await fetch("/api/productos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          activo: true,
        }),
      })

      const result = await response.json()

      if (!response.ok || !result.success) {
        throw new Error(result.error || "Error al crear producto")
      }

      toast({
        title: "¡Producto creado!",
        description: "El producto ha sido creado exitosamente",
      })

      onSuccess()
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al crear producto",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setFormData({
      nombre: "",
      identificador: "",
      descripcion: "",
      tipo_producto_id: "",
      categoria: "",
      precio_base: 0,
    })
  }

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(open) => {
        if (!open) {
          resetForm()
          onClose()
        }
      }}
    >
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Package className="w-5 h-5 mr-2" />
            Crear Nuevo Producto
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Nombre del Producto *</Label>
                  <Input
                    value={formData.nombre}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nombre: e.target.value }))}
                    placeholder="Ej: Ventana PVC 1.20x1.50"
                  />
                </div>

                <div>
                  <Label>Identificador</Label>
                  <Input
                    value={formData.identificador}
                    onChange={(e) => setFormData((prev) => ({ ...prev, identificador: e.target.value }))}
                    placeholder="Ej: VENT-PVC-120150"
                  />
                </div>
              </div>

              <div>
                <Label>Descripción</Label>
                <Textarea
                  value={formData.descripcion}
                  onChange={(e) => setFormData((prev) => ({ ...prev, descripcion: e.target.value }))}
                  placeholder="Descripción detallada del producto"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Tipo de Producto *</Label>
                  <Select
                    value={formData.tipo_producto_id}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, tipo_producto_id: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {tiposProducto.map((tipo) => (
                        <SelectItem key={tipo._id} value={tipo._id}>
                          {tipo.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Categoría</Label>
                  <Select
                    value={formData.categoria || "sin-categoria"}
                    onValueChange={(value) =>
                      setFormData((prev) => ({ ...prev, categoria: value === "sin-categoria" ? "" : value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sin-categoria">Sin categoría</SelectItem>
                      <SelectItem value="ventanas">Ventanas</SelectItem>
                      <SelectItem value="puertas">Puertas</SelectItem>
                      <SelectItem value="barandales">Barandales</SelectItem>
                      <SelectItem value="mamparas">Mamparas</SelectItem>
                      <SelectItem value="canceleria">Cancelería</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Precio Base (Opcional)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">L</span>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.precio_base}
                    onChange={(e) => setFormData((prev) => ({ ...prev, precio_base: Number(e.target.value) }))}
                    placeholder="0.00"
                    className="pl-8"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <Settings className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-100">Siguiente paso</h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">Después de crear el producto podrás:</p>
                  <ul className="text-sm text-blue-700 dark:text-blue-300 mt-2 space-y-1">
                    <li className="flex items-center">
                      <CheckCircle className="w-3 h-3 mr-2" />
                      Seleccionar materiales necesarios
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="w-3 h-3 mr-2" />
                      Configurar cantidades y fórmulas
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="w-3 h-3 mr-2" />
                      Definir variantes y precios
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end space-x-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creando...
              </>
            ) : (
              "Crear Producto"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
