"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { X, Upload, Code, Save } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface EditarProductoModalProps {
  isOpen: boolean
  onClose: () => void
  producto: any
  onProductoActualizado: () => void
}

export default function EditarProductoModal({
  isOpen,
  onClose,
  producto,
  onProductoActualizado,
}: EditarProductoModalProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [tiposProducto, setTiposProducto] = useState<any[]>([])

  const [formData, setFormData] = useState({
    nombre: "",
    identificador: "",
    descripcion: "",
    tipo_producto_id: "",
    categoria: "",
    precio_base: 0,
    imagen: null as File | null,
    imagenActual: "",
    svg: "",
    estado: true,
  })

  useEffect(() => {
    if (isOpen) {
      cargarTiposProducto()

      if (producto) {
        console.log("🔄 Cargando producto:", producto)
        setFormData({
          nombre: producto.nombre || "",
          identificador: producto.identificador || "",
          descripcion: producto.descripcion || "",
          tipo_producto_id: producto.tipo_producto_id || "",
          categoria: producto.categoria || "",
          precio_base: producto.precio_base || 0,
          imagen: null,
          imagenActual: producto.imagen || "",
          svg: producto.svg || "",
          estado: producto.estado ?? true,
        })
      }
    }
  }, [isOpen, producto])

  const cargarTiposProducto = async () => {
    try {
      const response = await fetch("/api/tipos-producto")
      const data = await response.json()
      setTiposProducto(data.tipos || [])
    } catch (error) {
      console.error("❌ Error cargando tipos de producto:", error)
      toast({
        title: "Error",
        description: "Error cargando tipos de producto",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: name === "precio_base" ? Number(value) : value,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSwitchChange = (checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      estado: checked,
    }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]

      // Validar tamaño (5MB máximo)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "La imagen no puede ser mayor a 5MB",
          variant: "destructive",
        })
        return
      }

      // Validar tipo
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Error",
          description: "Solo se permiten archivos de imagen",
          variant: "destructive",
        })
        return
      }

      setFormData((prev) => ({
        ...prev,
        imagen: file,
      }))
    }
  }

  const eliminarImagenActual = () => {
    setFormData((prev) => ({
      ...prev,
      imagenActual: "",
    }))
  }

  const eliminarImagenNueva = () => {
    setFormData((prev) => ({
      ...prev,
      imagen: null,
    }))
  }

  const handleSubmit = async () => {
    try {
      setLoading(true)
      console.log("🚀 Iniciando actualización del producto...")

      // Validaciones
      if (!formData.nombre.trim()) {
        toast({
          title: "Error",
          description: "El nombre del producto es requerido",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      if (!formData.tipo_producto_id) {
        toast({
          title: "Error",
          description: "Selecciona un tipo de producto",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      // Preparar FormData
      const formDataToSend = new FormData()
      formDataToSend.append("nombre", formData.nombre.trim())
      formDataToSend.append("identificador", formData.identificador.trim())
      formDataToSend.append("descripcion", formData.descripcion.trim())
      formDataToSend.append("tipo_producto_id", formData.tipo_producto_id)
      formDataToSend.append("categoria", formData.categoria || "")
      formDataToSend.append("precio_base", formData.precio_base.toString())
      formDataToSend.append("estado", formData.estado.toString())
      formDataToSend.append("svg", formData.svg.trim())
      formDataToSend.append("imagenActual", formData.imagenActual || "")

      if (formData.imagen) {
        formDataToSend.append("imagen", formData.imagen)
        console.log("📷 Imagen nueva agregada:", formData.imagen.name)
      }

      console.log("📤 Enviando datos al servidor...")

      const response = await fetch(`/api/productos/${producto._id}`, {
        method: "PUT",
        body: formDataToSend,
      })

      console.log("📡 Respuesta del servidor:", response.status)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || errorData.details || `Error ${response.status}: ${response.statusText}`)
      }

      const result = await response.json()
      console.log("✅ Producto actualizado:", result)

      // Verificar que tenemos los datos del producto
      if (result.success && result.producto) {
        toast({
          title: "¡Producto actualizado!",
          description: "El producto ha sido actualizado exitosamente",
        })

        // Llamar a la función de actualización
        onProductoActualizado()

        // Cerrar el modal
        onClose()

        // Limpiar el formulario
        setFormData({
          nombre: "",
          identificador: "",
          descripcion: "",
          tipo_producto_id: "",
          categoria: "",
          precio_base: 0,
          imagen: null,
          imagenActual: "",
          svg: "",
          estado: true,
        })
      } else {
        throw new Error("No se recibieron los datos del producto actualizado")
      }
    } catch (error) {
      console.error("❌ Error actualizando producto:", error)
      toast({
        title: "Error al actualizar",
        description: error.message || "Ocurrió un error inesperado",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Save className="w-5 h-5 mr-2" />
            Editar Producto
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="nombre">Nombre del Producto *</Label>
              <Input
                id="nombre"
                name="nombre"
                value={formData.nombre}
                onChange={handleInputChange}
                placeholder="Ej: Ventana Corrediza PVC"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="identificador">Identificador</Label>
              <Input
                id="identificador"
                name="identificador"
                value={formData.identificador}
                onChange={handleInputChange}
                placeholder="Ej: VENT-CORR-PVC"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                name="descripcion"
                value={formData.descripcion}
                onChange={handleInputChange}
                placeholder="Descripción detallada del producto"
                rows={4}
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="tipo_producto_id">Tipo de Producto *</Label>
                <Select
                  value={formData.tipo_producto_id}
                  onValueChange={(value) => handleSelectChange("tipo_producto_id", value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {tiposProducto.map((tipo) => (
                      <SelectItem key={tipo._id} value={tipo._id}>
                        {tipo.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="categoria">Categoría</Label>
                <Select
                  value={formData.categoria || "sin-categoria"}
                  onValueChange={(value) => handleSelectChange("categoria", value === "sin-categoria" ? "" : value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sin-categoria">Sin categoría</SelectItem>
                    <SelectItem value="ventanas">Ventanas</SelectItem>
                    <SelectItem value="puertas">Puertas</SelectItem>
                    <SelectItem value="barandales">Barandales</SelectItem>
                    <SelectItem value="mamparas">Mamparas</SelectItem>
                    <SelectItem value="canceleria">Cancelería</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="precio_base">Precio Base</Label>
              <div className="relative mt-1">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">L</span>
                <Input
                  id="precio_base"
                  name="precio_base"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.precio_base}
                  onChange={handleInputChange}
                  placeholder="0.00"
                  className="pl-8"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="estado" checked={formData.estado} onCheckedChange={handleSwitchChange} />
              <Label htmlFor="estado">Producto activo</Label>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="imagen">Imagen del Producto</Label>
              <Card className="mt-1">
                <CardContent className="p-4">
                  <div className="space-y-4">
                    {/* Imagen actual */}
                    {formData.imagenActual && !formData.imagen && (
                      <div className="relative">
                        <img
                          src={formData.imagenActual || "/placeholder.svg"}
                          alt="Imagen actual"
                          className="mx-auto max-h-40 object-contain rounded-lg border"
                          onError={(e) => {
                            e.currentTarget.src = "/placeholder.svg?height=160&width=160&text=Sin+imagen"
                          }}
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2"
                          onClick={eliminarImagenActual}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                        <p className="text-xs text-gray-500 mt-2 text-center">Imagen actual</p>
                      </div>
                    )}

                    {/* Nueva imagen */}
                    {formData.imagen && (
                      <div className="relative">
                        <img
                          src={URL.createObjectURL(formData.imagen) || "/placeholder.svg"}
                          alt="Nueva imagen"
                          className="mx-auto max-h-40 object-contain rounded-lg border"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2"
                          onClick={eliminarImagenNueva}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                        <p className="text-xs text-green-600 mt-2 text-center font-medium">Nueva imagen</p>
                      </div>
                    )}

                    {/* Área de subida */}
                    {!formData.imagen && (
                      <div className="flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6">
                        <div className="text-center">
                          <Upload className="mx-auto h-12 w-12 text-gray-400" />
                          <div className="mt-2">
                            <label
                              htmlFor="file-upload"
                              className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500"
                            >
                              <span>{formData.imagenActual ? "Cambiar imagen" : "Subir imagen"}</span>
                              <input
                                id="file-upload"
                                name="file-upload"
                                type="file"
                                className="sr-only"
                                accept="image/*"
                                onChange={handleImageChange}
                              />
                            </label>
                          </div>
                          <p className="text-xs text-gray-500">PNG, JPG, GIF hasta 5MB</p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Label htmlFor="svg" className="flex items-center">
                <Code className="w-4 h-4 mr-2" />
                Código SVG (Opcional)
              </Label>
              <Textarea
                id="svg"
                name="svg"
                value={formData.svg}
                onChange={handleInputChange}
                placeholder="<svg>...</svg>"
                rows={8}
                className="font-mono text-sm mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                El SVG se utilizará para representar el producto en la cotización
              </p>

              {formData.svg && (
                <div className="mt-2 p-3 border rounded-lg bg-gray-50 dark:bg-gray-800">
                  <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">Vista previa del SVG:</p>
                  <div
                    className="flex justify-center"
                    dangerouslySetInnerHTML={{ __html: formData.svg }}
                    style={{ maxHeight: "100px" }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4 pt-4 border-t">
          <Button variant="outline" onClick={onClose} disabled={loading}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            <Save className="w-4 h-4 mr-2" />
            {loading ? "Actualizando..." : "Actualizar Producto"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
