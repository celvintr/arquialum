import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

interface Params {
  id: string
}

export async function PUT(request: Request, { params }: { params: Params }) {
  try {
    const { id } = params

    if (!id) {
      return new NextResponse("Cotización ID is required", { status: 400 })
    }

    const { estadoPago } = await request.json()

    if (!estadoPago) {
      return new NextResponse("Estado de pago is required", { status: 400 })
    }

    const cotizacion = await prisma.cotizacion.update({
      where: {
        id: id,
      },
      data: {
        estadoPago: estadoPago,
      },
    })

    return NextResponse.json(cotizacion)
  } catch (error) {
    console.log("[COTIZACION_ESTADO_PAGO_PUT]", error)
    return new NextResponse("Internal error", { status: 500 })
  }
}
