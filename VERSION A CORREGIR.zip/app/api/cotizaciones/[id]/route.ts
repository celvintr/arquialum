import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

interface Params {
  id: string
}

export async function GET(request: Request, { params }: { params: Params }) {
  try {
    const { id } = params
    const cotizacion = await prisma.cotizacion.findUnique({
      where: {
        id: String(id),
      },
      include: {
        cliente: true,
        items: true,
      },
    })

    if (!cotizacion) {
      return new NextResponse(JSON.stringify({ message: "Cotización no encontrada" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      })
    }

    return new NextResponse(JSON.stringify(cotizacion), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error(error)
    return new NextResponse(JSON.stringify({ message: "Error al obtener la cotización" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

export async function PUT(request: Request, { params }: { params: Params }) {
  try {
    const { id } = params
    const body = await request.json()
    const { clienteId, fecha, observaciones, items } = body

    const updatedCotizacion = await prisma.cotizacion.update({
      where: {
        id: String(id),
      },
      data: {
        clienteId: clienteId,
        fecha: new Date(fecha),
        observaciones: observaciones,
        items: {
          deleteMany: {}, // Delete all existing items
          create: items.map((item: any) => ({
            productoId: item.productoId,
            cantidad: item.cantidad,
            precioUnitario: item.precioUnitario,
          })),
        },
      },
      include: {
        cliente: true,
        items: true,
      },
    })

    return new NextResponse(JSON.stringify(updatedCotizacion), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error(error)
    return new NextResponse(JSON.stringify({ message: "Error al actualizar la cotización" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

export async function DELETE(request: Request, { params }: { params: Params }) {
  try {
    const { id } = params

    await prisma.cotizacion.delete({
      where: {
        id: String(id),
      },
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    console.error(error)
    return new NextResponse(JSON.stringify({ message: "Error al eliminar la cotización" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
