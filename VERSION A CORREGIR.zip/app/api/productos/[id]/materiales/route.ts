import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const id = await params.id

  try {
    // Simulate fetching materiales based on productId
    const materiales = [
      { id: 1, name: "Material A", productId: id },
      { id: 2, name: "Material B", productId: id },
    ]

    return NextResponse.json(materiales)
  } catch (error) {
    console.error("Error fetching materiales:", error)
    return NextResponse.json({ error: "Failed to fetch materiales" }, { status: 500 })
  }
}
