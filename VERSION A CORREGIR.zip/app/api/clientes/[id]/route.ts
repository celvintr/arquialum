import { NextResponse } from "next/server"
import { prisma } from "@/libs/prisma"

interface Params {
  params: { id: string }
}

export async function GET(request: Request, { params }: Params) {
  try {
    const { id } = await params

    const cliente = await prisma.cliente.findUnique({
      where: {
        id: id,
      },
    })

    if (!cliente) return NextResponse.json({ message: "Cliente not found" }, { status: 404 })

    return NextResponse.json(cliente)
  } catch (error) {
    if (error instanceof Error) {
      return NextResponse.json(
        {
          message: error.message,
        },
        {
          status: 500,
        },
      )
    }
  }
}

export async function PUT(request: Request, { params }: Params) {
  try {
    const { id } = await params
    const { nombre, direccion, telefono, email } = await request.json()

    const updatedCliente = await prisma.cliente.update({
      where: {
        id: id,
      },
      data: {
        nombre,
        direccion,
        telefono,
        email,
      },
    })

    return NextResponse.json(updatedCliente)
  } catch (error) {
    if (error instanceof Error) {
      return NextResponse.json(
        {
          message: error.message,
        },
        {
          status: 500,
        },
      )
    }
  }
}

export async function DELETE(request: Request, { params }: Params) {
  try {
    const { id } = await params

    await prisma.cliente.delete({
      where: {
        id: id,
      },
    })

    return new NextResponse(null, {
      status: 204,
    })
  } catch (error) {
    if (error instanceof Error) {
      return NextResponse.json(
        {
          message: error.message,
        },
        {
          status: 500,
        },
      )
    }
  }
}
