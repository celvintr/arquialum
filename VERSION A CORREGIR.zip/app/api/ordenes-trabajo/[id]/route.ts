import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

interface Params {
  id: string
}

export async function GET(request: Request, { params }: { params: Params }) {
  const { id } = params

  try {
    const ordenTrabajo = await prisma.ordenTrabajo.findUnique({
      where: {
        id: id,
      },
      include: {
        cliente: true,
        vehiculo: true,
        tareas: true,
      },
    })

    if (!ordenTrabajo) {
      return new NextResponse(JSON.stringify({ message: "Orden de trabajo no encontrada" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      })
    }

    return new NextResponse(JSON.stringify(ordenTrabajo), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error(error)
    return new NextResponse(JSON.stringify({ message: "Error al obtener la orden de trabajo" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

export async function PUT(request: Request, { params }: { params: Params }) {
  try {
    const { id } = params
    const json = await request.json()

    const updatedOrdenTrabajo = await prisma.ordenTrabajo.update({
      where: {
        id: id,
      },
      data: json,
    })

    return new NextResponse(JSON.stringify(updatedOrdenTrabajo), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error(error)
    return new NextResponse(JSON.stringify({ message: "Error al actualizar la orden de trabajo" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

export async function DELETE(request: Request, { params }: { params: Params }) {
  try {
    const { id } = params

    await prisma.ordenTrabajo.delete({
      where: {
        id: id,
      },
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    console.error(error)
    return new NextResponse(JSON.stringify({ message: "Error al eliminar la orden de trabajo" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
