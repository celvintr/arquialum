import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;

    if (!id) {
      return NextResponse.json({ error: "Material ID is required" }, { status: 400 });
    }

    const materialId = parseInt(id, 10);

    if (isNaN(materialId)) {
      return NextResponse.json({ error: "Invalid Material ID" }, { status: 400 });
    }

    // Check if the material is used in any products
    const productsUsingMaterial = await prisma.product.findMany({
      where: {
        materials: {
          some: {
            id: materialId,
          },
        },
      },
    });

    const isUsed = productsUsingMaterial.length > 0;

    return NextResponse.json({ isUsed, products: productsUsingMaterial });

  } catch (error) {
    console.error("Error checking material usage:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  } finally {
    await prisma.$disconnect();
  }
}
