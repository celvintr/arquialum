export class SessionManager {
  private static readonly SESSION_KEY = "cotizacion_session"
  private static readonly IMAGES_KEY = "cotizacion_images"

  static guardarSesion(data: any) {
    try {
      // Procesar grupos para guardar imágenes como base64
      const gruposConImagenes = data.grupos || []
      const gruposProcesados = gruposConImagenes.map((grupo: any) => {
        // Si ya tiene imagenUrl y no tiene imagen nueva, mantener la URL
        if (grupo.imagenUrl && !grupo.imagen) {
          return {
            ...grupo,
            imagen: null, // No guardar el objeto File
          }
        }

        // Si tiene imagen nueva (File), convertirla a base64
        if (grupo.imagen instanceof File) {
          // Aquí no convertimos a base64 directamente porque es asíncrono
          // Solo marcamos que tiene imagen para procesarla después
          return {
            ...grupo,
            tieneImagenNueva: true,
            imagen: null, // No guardar el objeto File
          }
        }

        return {
          ...grupo,
          imagen: null, // No guardar el objeto File
        }
      })

      // Crear objeto de sesión
      const sessionData = {
        ...data,
        id: `session_${Date.now()}`,
        timestamp: new Date().toISOString(),
        grupos: gruposProcesados,
      }

      localStorage.setItem(this.SESSION_KEY, JSON.stringify(sessionData))

      // Guardar imágenes por separado para evitar problemas de tamaño
      this.guardarImagenesGrupos(data.grupos || [])

      console.log("✅ Sesión guardada:", sessionData.timestamp)
    } catch (error) {
      console.error("❌ Error guardando sesión:", error)
    }
  }

  static cargarSesion() {
    try {
      const sessionStr = localStorage.getItem(this.SESSION_KEY)
      if (!sessionStr) return null

      const session = JSON.parse(sessionStr)

      // Cargar imágenes guardadas
      const imagenesGuardadas = this.cargarImagenesGrupos()

      // Restaurar URLs de imágenes
      if (session.grupos && session.grupos.length > 0) {
        session.grupos = session.grupos.map((grupo: any) => {
          const imagenGuardada = imagenesGuardadas[grupo.id]

          return {
            ...grupo,
            imagenUrl: imagenGuardada || grupo.imagenUrl,
            imagen: null,
          }
        })
      }

      return session
    } catch (error) {
      console.error("❌ Error cargando sesión:", error)
      return null
    }
  }

  static limpiarSesion() {
    try {
      localStorage.removeItem(this.SESSION_KEY)
      localStorage.removeItem(this.IMAGES_KEY)
      console.log("🗑️ Sesión limpiada")
    } catch (error) {
      console.error("❌ Error limpiando sesión:", error)
    }
  }

  static getInfoSesion() {
    try {
      const sessionStr = localStorage.getItem(this.SESSION_KEY)
      if (!sessionStr) return null

      const session = JSON.parse(sessionStr)
      return {
        timestamp: session.timestamp,
        itemsCount: session.items?.length || 0,
        gruposCount: session.grupos?.length || 0,
        cliente: session.cliente?.nombre || null,
      }
    } catch (error) {
      return null
    }
  }

  private static async guardarImagenesGrupos(grupos: any[]) {
    try {
      // Cargar imágenes existentes
      const imagenesExistentes = this.cargarImagenesGrupos()
      const nuevasImagenes = { ...imagenesExistentes }

      // Procesar cada grupo
      for (const grupo of grupos) {
        // Si el grupo tiene una imagen como File, convertirla a base64
        if (grupo.imagen instanceof File) {
          const base64 = await this.convertirImagenABase64(grupo.imagen)
          nuevasImagenes[grupo.id] = base64
        }
        // Si tiene imagenUrl pero no es base64, mantenerla
        else if (grupo.imagenUrl && !grupo.imagenUrl.startsWith("data:")) {
          nuevasImagenes[grupo.id] = grupo.imagenUrl
        }
      }

      // Guardar todas las imágenes
      localStorage.setItem(this.IMAGES_KEY, JSON.stringify(nuevasImagenes))
    } catch (error) {
      console.error("Error guardando imágenes:", error)
    }
  }

  private static cargarImagenesGrupos(): Record<string, string> {
    try {
      const imagenesStr = localStorage.getItem(this.IMAGES_KEY)
      return imagenesStr ? JSON.parse(imagenesStr) : {}
    } catch (error) {
      console.error("Error cargando imágenes:", error)
      return {}
    }
  }

  static validarImagen(file: File): { valida: boolean; error?: string } {
    // Validar tipo
    if (!file.type.startsWith("image/")) {
      return { valida: false, error: "Solo se permiten archivos de imagen" }
    }

    // Validar tamaño (máx 5MB)
    if (file.size > 5 * 1024 * 1024) {
      return { valida: false, error: "La imagen no debe superar los 5MB" }
    }

    return { valida: true }
  }

  static async convertirImagenABase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (e) => resolve(e.target?.result as string)
      reader.onerror = reject
      reader.readAsDataURL(file)
    })
  }
}
