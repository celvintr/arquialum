export class FormulaCalculator {
  private dimensiones: any

  constructor(dimensiones: any) {
    this.dimensiones = dimensiones
  }

  calcularCantidad(formula: string): number {
    try {
      // Limpiar fórmula
      let formulaLimpia = formula.trim()
      if (formulaLimpia.startsWith("=")) {
        formulaLimpia = formulaLimpia.substring(1)
      }

      // Reemplazar variables
      formulaLimpia = this.reemplazarVariables(formulaLimpia)

      // Transformar funciones de Excel
      formulaLimpia = this.transformarFunciones(formulaLimpia)

      // Evaluar fórmula de forma segura
      const resultado = this.evaluarFormula(formulaLimpia)

      return isNaN(resultado) ? 0 : Math.max(0, resultado)
    } catch (error) {
      console.error("Error calculando cantidad:", error)
      return 0
    }
  }

  private reemplazarVariables(formula: string): string {
    const { ancho, alto, divisionHorizontal, divisionVertical, decoradoHorizontal, decoradoVertical } = this.dimensiones

    return formula
      .replace(/\bancho\b/g, ancho.toString())
      .replace(/\balto\b/g, alto.toString())
      .replace(/\bdivisionHorizontal\b/g, divisionHorizontal.toString())
      .replace(/\bdivisionVertical\b/g, divisionVertical.toString())
      .replace(/\bdecoradoHorizontal\b/g, decoradoHorizontal.toString())
      .replace(/\bdecoradoVertical\b/g, decoradoVertical.toString())
  }

  private transformarFunciones(formula: string): string {
    // REDONDEAR.MENOS -> Math.floor
    formula = formula.replace(/REDONDEAR\.MENOS\s*$$\s*([^,)]+)\s*(?:,\s*[^)]+)?\s*$$/g, "Math.floor($1)")

    // ROUNDUP -> Math.ceil con precisión
    formula = formula.replace(/ROUNDUP\s*$$\s*([^,]+)\s*,\s*(\d+)\s*$$/g, (match, num, precision) => {
      if (precision === "0") {
        return `Math.ceil(${num})`
      }
      const multiplier = Math.pow(10, Number.parseInt(precision))
      return `Math.ceil(${num} * ${multiplier}) / ${multiplier}`
    })

    // SI -> operador ternario
    formula = formula.replace(/SI\s*$$\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*$$/g, "($1) ? ($2) : ($3)")

    // Operadores lógicos
    formula = formula.replace(/\s+Y\s+/g, " && ")
    formula = formula.replace(/\s+O\s+/g, " || ")

    return formula
  }

  private evaluarFormula(formula: string): number {
    try {
      // Crear función segura para evaluar
      const func = new Function(
        "Math",
        `
        "use strict";
        return ${formula};
      `,
      )

      return func(Math)
    } catch (error) {
      console.error("Error evaluando fórmula:", formula, error)
      return 0
    }
  }

  calcularRendimiento(materialCalculado: number, areaLongitud: number): number {
    if (areaLongitud === 0) return 0

    // Rendimiento = Material calculado ÷ área_longitud del material
    const rendimiento = materialCalculado / areaLongitud

    // Redondear a 4 decimales para precisión
    return Math.round(rendimiento * 10000) / 10000
  }

  calcularManoObra(ancho: number, alto: number, tipoProducto: number, tipo: string): number {
    const area = ancho * alto

    switch (tipo) {
      case "fabricacion":
        if (tipoProducto === 10) return 0 // Tipo especial sin mano de obra
        return area * 400 // 400 lempiras por m²

      case "instalacion":
        if (tipoProducto === 10) return 0
        return area * 200 // 200 lempiras por m²

      case "malla":
        // Solo ciertos tipos llevan malla
        if ([3, 6, 10].includes(tipoProducto)) return 0
        return area * 0.25 * 400 // 25% del área * 400 lempiras

      default:
        return 0
    }
  }
}

// Función para calcular totales de cotización
export function calcularTotalCotizacion(items: any[]) {
  const subtotal = items.reduce((total, item) => total + (item.precio_total || 0), 0)
  const iva = subtotal * 0.16 // 16% IVA
  const total = subtotal + iva

  return {
    subtotal,
    iva,
    total,
    cantidad_items: items.length,
  }
}

// Función para generar número de cotización
export function generarNumeroCotizacion(): string {
  const fecha = new Date()
  const año = fecha.getFullYear()
  const mes = String(fecha.getMonth() + 1).padStart(2, "0")
  const dia = String(fecha.getDate()).padStart(2, "0")
  const timestamp = Date.now().toString().slice(-4) // Últimos 4 dígitos del timestamp

  return `COT-${año}${mes}${dia}-${timestamp}`
}
