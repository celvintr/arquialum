"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { FolderOpen, Plus, Edit, Trash2, Users, ImageIcon, Upload, X, Check } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { SessionManager } from "@/lib/utils/session-manager"

interface GruposManagerProps {
  grupos: any[]
  grupoActivo: string
  items: any[]
  onGrupoSeleccionado: (grupoId: string) => void
  onCrearGrupo: (nombre: string, imagen?: File, descripcion?: string) => void
  onEliminarGrupo: (grupoId: string) => void
  onActualizarGrupo: (grupoId: string, datos: any) => void
}

export default function GruposManager({
  grupos,
  grupoActivo,
  items,
  onGrupoSeleccionado,
  onCrearGrupo,
  onEliminarGrupo,
  onActualizarGrupo,
}: GruposManagerProps) {
  const { toast } = useToast()
  const [modalCrear, setModalCrear] = useState(false)
  const [modalEditar, setModalEditar] = useState(false)
  const [grupoEditando, setGrupoEditando] = useState<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const fileInputEditRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    nombre: "",
    descripcion: "",
    imagen: null as File | null,
    imagenPreview: "",
  })

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleImagenChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const validacion = SessionManager.validarImagen(file)
    if (!validacion.valida) {
      toast({
        title: "Error",
        description: validacion.error,
        variant: "destructive",
      })
      return
    }

    // Crear URL para previsualización
    const previewUrl = URL.createObjectURL(file)

    setFormData((prev) => ({
      ...prev,
      imagen: file,
      imagenPreview: previewUrl,
    }))
  }

  const handleCrearGrupo = () => {
    if (!formData.nombre.trim()) {
      toast({
        title: "Error",
        description: "El nombre del grupo es requerido",
        variant: "destructive",
      })
      return
    }

    onCrearGrupo(formData.nombre, formData.imagen || undefined, formData.descripcion)
    resetForm()
    setModalCrear(false)

    toast({
      title: "Grupo creado",
      description: `El grupo "${formData.nombre}" ha sido creado exitosamente`,
    })
  }

  const handleEditarGrupo = () => {
    if (!formData.nombre.trim()) {
      toast({
        title: "Error",
        description: "El nombre del grupo es requerido",
        variant: "destructive",
      })
      return
    }

    onActualizarGrupo(grupoEditando.id, {
      nombre: formData.nombre,
      descripcion: formData.descripcion,
      imagen: formData.imagen,
    })

    resetForm()
    setModalEditar(false)
    setGrupoEditando(null)

    toast({
      title: "Grupo actualizado",
      description: `El grupo "${formData.nombre}" ha sido actualizado`,
    })
  }

  const abrirModalEditar = (grupo: any) => {
    setGrupoEditando(grupo)
    setFormData({
      nombre: grupo.nombre,
      descripcion: grupo.descripcion || "",
      imagen: null,
      imagenPreview: grupo.imagenUrl || "",
    })
    setModalEditar(true)
  }

  const resetForm = () => {
    setFormData({
      nombre: "",
      descripcion: "",
      imagen: null,
      imagenPreview: "",
    })
  }

  const contarItemsPorGrupo = (grupoId: string) => {
    return items.filter((item) => item.grupoId === grupoId || (!item.grupoId && grupoId === "default")).length
  }

  const eliminarImagen = () => {
    setFormData((prev) => ({
      ...prev,
      imagen: null,
      imagenPreview: "",
    }))

    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }

    if (fileInputEditRef.current) {
      fileInputEditRef.current.value = ""
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <FolderOpen className="w-5 h-5 mr-2" />
            Gestión de Grupos ({grupos.length})
          </CardTitle>
          <Dialog open={modalCrear} onOpenChange={setModalCrear}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800">
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Grupo
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold">Crear Nuevo Grupo</DialogTitle>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Nombre del Grupo</Label>
                  <Input
                    value={formData.nombre}
                    onChange={(e) => handleInputChange("nombre", e.target.value)}
                    placeholder="Ej: Área Exterior, Cocina, etc."
                    className="border-2 focus:border-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Descripción</Label>
                  <Textarea
                    value={formData.descripcion}
                    onChange={(e) => handleInputChange("descripcion", e.target.value)}
                    placeholder="Descripción opcional del grupo..."
                    rows={3}
                    className="border-2 focus:border-blue-500"
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Imagen del Grupo</Label>

                  {formData.imagenPreview ? (
                    <div className="relative">
                      <img
                        src={formData.imagenPreview || "/placeholder.svg"}
                        alt="Vista previa"
                        className="w-full h-48 object-cover rounded-lg border-2 border-blue-300"
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 rounded-full w-8 h-8"
                        onClick={eliminarImagen}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div
                      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="w-10 h-10 mx-auto text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Haga clic para seleccionar una imagen</p>
                      <p className="text-xs text-gray-400 mt-1">JPG, PNG, GIF o WebP (máx. 5MB)</p>
                      <Input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImagenChange}
                        className="hidden"
                      />
                    </div>
                  )}
                </div>

                <div className="flex justify-end space-x-2 pt-4 border-t">
                  <Button variant="outline" onClick={() => setModalCrear(false)}>
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleCrearGrupo}
                    className="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Crear Grupo
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {grupos.map((grupo) => {
            const itemsCount = contarItemsPorGrupo(grupo.id)
            const isActive = grupo.id === grupoActivo

            return (
              <Card
                key={grupo.id}
                className={`cursor-pointer transition-all border-2 hover:shadow-lg ${
                  isActive
                    ? "border-blue-500 bg-gradient-to-br from-blue-50 to-blue-100 shadow-md"
                    : "border-gray-200 hover:border-gray-300"
                }`}
                onClick={() => onGrupoSeleccionado(grupo.id)}
              >
                <CardContent className="p-4">
                  {/* Imagen del grupo */}
                  <div className="relative mb-3">
                    {grupo.imagenUrl ? (
                      <img
                        src={grupo.imagenUrl || "/placeholder.svg"}
                        alt={grupo.nombre}
                        className="w-full h-24 object-cover rounded-lg shadow-sm"
                      />
                    ) : (
                      <div className="w-full h-24 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg flex items-center justify-center">
                        <FolderOpen className="w-8 h-8 text-blue-500" />
                      </div>
                    )}

                    {/* Badge de items */}
                    <Badge
                      className={`absolute -top-2 -right-2 ${
                        itemsCount > 0
                          ? "bg-gradient-to-r from-green-500 to-green-600"
                          : "bg-gradient-to-r from-gray-400 to-gray-500"
                      }`}
                    >
                      {itemsCount}
                    </Badge>
                  </div>

                  {/* Información del grupo */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-sm truncate">{grupo.nombre}</h3>
                      {isActive && (
                        <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                          Activo
                        </Badge>
                      )}
                    </div>

                    {grupo.descripcion && <p className="text-xs text-gray-600 line-clamp-2">{grupo.descripcion}</p>}

                    {/* Estadísticas */}
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center">
                        <Users className="w-3 h-3 mr-1" />
                        {itemsCount} items
                      </div>
                      {grupo.imagenUrl && (
                        <div className="flex items-center">
                          <ImageIcon className="w-3 h-3 mr-1" />
                          Imagen
                        </div>
                      )}
                    </div>

                    {/* Acciones */}
                    {grupo.id !== "default" && (
                      <div className="flex justify-end space-x-1 pt-2 border-t">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="hover:bg-blue-100 hover:text-blue-700"
                          onClick={(e) => {
                            e.stopPropagation()
                            abrirModalEditar(grupo)
                          }}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="hover:bg-red-100 hover:text-red-700"
                          onClick={(e) => {
                            e.stopPropagation()
                            onEliminarGrupo(grupo.id)
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Modal de Editar */}
        <Dialog open={modalEditar} onOpenChange={setModalEditar}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">Editar Grupo</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Nombre del Grupo</Label>
                <Input
                  value={formData.nombre}
                  onChange={(e) => handleInputChange("nombre", e.target.value)}
                  placeholder="Nombre del grupo"
                  className="border-2 focus:border-blue-500"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Descripción</Label>
                <Textarea
                  value={formData.descripcion}
                  onChange={(e) => handleInputChange("descripcion", e.target.value)}
                  placeholder="Descripción del grupo..."
                  rows={3}
                  className="border-2 focus:border-blue-500"
                />
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">Imagen del Grupo</Label>

                {formData.imagenPreview ? (
                  <div className="relative">
                    <img
                      src={formData.imagenPreview || "/placeholder.svg"}
                      alt="Vista previa"
                      className="w-full h-48 object-cover rounded-lg border-2 border-blue-300"
                    />
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 rounded-full w-8 h-8"
                      onClick={eliminarImagen}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
                    onClick={() => fileInputEditRef.current?.click()}
                  >
                    <Upload className="w-10 h-10 mx-auto text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">Haga clic para seleccionar una imagen</p>
                    <p className="text-xs text-gray-400 mt-1">JPG, PNG, GIF o WebP (máx. 5MB)</p>
                    <Input
                      ref={fileInputEditRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImagenChange}
                      className="hidden"
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setModalEditar(false)}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleEditarGrupo}
                  className="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Guardar Cambios
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}
