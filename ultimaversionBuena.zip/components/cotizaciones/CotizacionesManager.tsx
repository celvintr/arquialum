"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Package,
  Wrench,
  GlassWater,
  FileText,
  ShoppingCart,
  Plus,
  Save,
  RefreshCw,
  Trash2,
  Edit,
  AlertCircle,
} from "lucide-react"
import CotizarProductoModal from "./CotizarProductoModal"
import CotizarReparacionModal from "./CotizarReparacionModal"
import CotizarVidrioTempladoModal from "./CotizarVidrioTempladoModal"
import CotizacionLibreModal from "./CotizacionLibreModal"
import ClienteSelector from "./ClienteSelector"
import ResumenCotizacion from "./ResumenCotizacion"
import GruposManager from "./GruposManager"
import SeleccionarProductoModal from "./SeleccionarProductoModal"
import { useToast } from "@/components/ui/use-toast"
import { SessionManager } from "@/lib/utils/session-manager"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface CotizacionesManagerProps {
  tipoCotizacion?: string
}

export default function CotizacionesManager({ tipoCotizacion }: CotizacionesManagerProps) {
  const { toast } = useToast()

  // Estados principales
  const [items, setItems] = useState<any[]>([])
  const [cliente, setCliente] = useState<any>(null)
  const [productos, setProductos] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [guardando, setGuardando] = useState(false)

  // Estados de modales
  const [modalProducto, setModalProducto] = useState(false)
  const [modalReparacion, setModalReparacion] = useState(false)
  const [modalVidrioTemplado, setModalVidrioTemplado] = useState(false)
  const [modalLibre, setModalLibre] = useState(false)
  const [modalSeleccionProducto, setModalSeleccionProducto] = useState(false)
  const [productoSeleccionado, setProductoSeleccionado] = useState<any>(null)
  const [itemEditando, setItemEditando] = useState<any>(null)

  // Estados de grupos
  const [grupos, setGrupos] = useState<any[]>([
    {
      id: "default",
      nombre: "Items Generales",
      descripcion: "Items sin grupo específico",
      items: [],
      imagen: null,
      imagenUrl: null,
    },
  ])
  const [grupoActivo, setGrupoActivo] = useState("default")

  // Estado de sesión
  const [sesionInfo, setSesionInfo] = useState<any>(null)
  const [autoGuardado, setAutoGuardado] = useState(false)
  const [errorSesion, setErrorSesion] = useState<string | null>(null)

  useEffect(() => {
    // Cargar productos si es necesario
    if (tipoCotizacion === "productos") {
      cargarProductos()
    }

    // Cargar sesión guardada
    cargarSesionGuardada()

    // Auto-guardado cada 10 segundos
    const interval = setInterval(() => {
      if (items.length > 0 || cliente) {
        guardarSesionAutomatica()
      }
    }, 10000)

    return () => clearInterval(interval)
  }, [tipoCotizacion])

  // Auto-guardar cuando cambien los datos importantes
  useEffect(() => {
    if (items.length > 0 || cliente) {
      const timeoutId = setTimeout(guardarSesionAutomatica, 2000)
      return () => clearTimeout(timeoutId)
    }
  }, [items, cliente, grupos, grupoActivo])

  const cargarProductos = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/productos")
      const data = await response.json()
      setProductos(data.productos || [])
    } catch (error) {
      console.error("Error cargando productos:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los productos",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const cargarSesionGuardada = () => {
    try {
      const session = SessionManager.cargarSesion()
      if (session) {
        setItems(session.items || [])
        setCliente(session.cliente || null)

        // Asegurarse de que siempre haya al menos el grupo default
        const gruposCargados = session.grupos || []
        if (gruposCargados.length === 0 || !gruposCargados.find((g: any) => g.id === "default")) {
          gruposCargados.push({
            id: "default",
            nombre: "Items Generales",
            descripcion: "Items sin grupo específico",
            items: [],
            imagen: null,
            imagenUrl: null,
          })
        }

        setGrupos(gruposCargados)
        setGrupoActivo(session.grupoActivo || "default")
        setSesionInfo(SessionManager.getInfoSesion())

        toast({
          title: "Sesión recuperada",
          description: `Se recuperaron ${session.items?.length || 0} items de la sesión anterior`,
        })

        setErrorSesion(null)
      }
    } catch (error) {
      console.error("Error al cargar la sesión:", error)
      setErrorSesion(
        "Hubo un problema al cargar la sesión guardada. Algunos datos podrían no haberse recuperado correctamente.",
      )
    }
  }

  const guardarSesionAutomatica = () => {
    try {
      setGuardando(true)

      SessionManager.guardarSesion({
        cliente,
        items,
        grupos,
        grupoActivo,
      })

      setSesionInfo(SessionManager.getInfoSesion())
      setAutoGuardado(true)
      setErrorSesion(null)

      // Quitar indicador después de 2 segundos
      setTimeout(() => setAutoGuardado(false), 2000)
    } catch (error) {
      console.error("Error al guardar sesión:", error)
      setErrorSesion("No se pudo guardar la sesión automáticamente. Intente guardar manualmente.")
    } finally {
      setGuardando(false)
    }
  }

  const guardarSesionManual = () => {
    try {
      setGuardando(true)

      SessionManager.guardarSesion({
        cliente,
        items,
        grupos,
        grupoActivo,
      })

      setSesionInfo(SessionManager.getInfoSesion())
      setErrorSesion(null)

      toast({
        title: "Sesión guardada",
        description: "La cotización ha sido guardada localmente",
      })
    } catch (error) {
      console.error("Error al guardar sesión manualmente:", error)
      toast({
        title: "Error",
        description: "No se pudo guardar la sesión. Intente de nuevo.",
        variant: "destructive",
      })
    } finally {
      setGuardando(false)
    }
  }

  const limpiarSesion = () => {
    SessionManager.limpiarSesion()
    setItems([])
    setCliente(null)
    setGrupos([
      {
        id: "default",
        nombre: "Items Generales",
        descripcion: "Items sin grupo específico",
        items: [],
        imagen: null,
        imagenUrl: null,
      },
    ])
    setGrupoActivo("default")
    setSesionInfo(null)
    setErrorSesion(null)

    toast({
      title: "Sesión limpiada",
      description: "Se han eliminado todos los datos guardados",
    })
  }

  const agregarItem = (item: any) => {
    if (itemEditando) {
      // Estamos editando un item existente
      setItems((prev) =>
        prev.map((existingItem) =>
          existingItem.id === itemEditando.id
            ? { ...item, id: itemEditando.id, timestamp: itemEditando.timestamp }
            : existingItem,
        ),
      )

      toast({
        title: "Item actualizado",
        description: `Item actualizado en el grupo: ${grupos.find((g) => g.id === (item.grupoId || grupoActivo))?.nombre}`,
      })

      setItemEditando(null)
    } else {
      // Estamos agregando un item nuevo
      const nuevoItem = {
        ...item,
        id: Date.now(),
        grupoId: grupoActivo,
        timestamp: new Date().toISOString(),
      }

      setItems((prev) => [...prev, nuevoItem])

      toast({
        title: "Item agregado",
        description: `Item agregado al grupo: ${grupos.find((g) => g.id === grupoActivo)?.nombre}`,
      })
    }
  }

  const eliminarItem = (itemId: number) => {
    setItems((prev) => prev.filter((item) => item.id !== itemId))
    toast({
      title: "Item eliminado",
      description: "El item ha sido eliminado de la cotización",
    })
  }

  const editarItem = (itemId: number) => {
    const item = items.find((i) => i.id === itemId)
    if (!item) return

    setItemEditando(item)

    // Abrir el modal correspondiente según el tipo
    switch (item.tipo) {
      case "producto":
        // Para productos, necesitamos cargar el producto original
        if (item.producto_id) {
          const producto = productos.find((p) => p._id === item.producto_id) || {
            _id: item.producto_id,
            nombre: item.producto_nombre || item.nombre,
            imagen: item.producto_imagen,
          }
          setProductoSeleccionado(producto)
        }
        setModalProducto(true)
        break
      case "reparacion":
        setModalReparacion(true)
        break
      case "vidrio_templado":
      case "barandal":
        setModalVidrioTemplado(true)
        break
      case "libre":
        setModalLibre(true)
        break
      default:
        toast({
          title: "No disponible",
          description: "La edición de este tipo de item no está disponible aún",
          variant: "destructive",
        })
    }
  }

  const actualizarCantidadItem = (itemId: number, nuevaCantidad: number) => {
    if (nuevaCantidad <= 0) return

    setItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const precioUnitario = item.precio_unitario || item.precio_total / item.cantidad
          return {
            ...item,
            cantidad: nuevaCantidad,
            precio_total: precioUnitario * nuevaCantidad,
          }
        }
        return item
      }),
    )

    toast({
      title: "Cantidad actualizada",
      description: `Cantidad actualizada a ${nuevaCantidad}`,
    })
  }

  const moverItemAGrupo = (itemId: number, nuevoGrupoId: string) => {
    setItems((prev) => prev.map((item) => (item.id === itemId ? { ...item, grupoId: nuevoGrupoId } : item)))

    const grupoDestino = grupos.find((g) => g.id === nuevoGrupoId)
    toast({
      title: "Item movido",
      description: `Item movido a: ${grupoDestino?.nombre}`,
    })
  }

  const crearGrupo = (nombre: string, imagen?: File, descripcion?: string) => {
    const nuevoGrupo = {
      id: `grupo_${Date.now()}`,
      nombre,
      descripcion: descripcion || "",
      items: [],
      imagen: imagen || null,
      imagenUrl: imagen ? URL.createObjectURL(imagen) : null,
    }

    setGrupos((prev) => [...prev, nuevoGrupo])
    setGrupoActivo(nuevoGrupo.id)

    // Guardar inmediatamente para asegurar que la imagen se procese
    setTimeout(() => {
      guardarSesionAutomatica()
    }, 500)
  }

  const eliminarGrupo = (grupoId: string) => {
    if (grupoId === "default") {
      toast({
        title: "No permitido",
        description: "No se puede eliminar el grupo por defecto",
        variant: "destructive",
      })
      return
    }

    // Mover items del grupo eliminado al grupo por defecto
    setItems((prev) => prev.map((item) => (item.grupoId === grupoId ? { ...item, grupoId: "default" } : item)))

    setGrupos((prev) => prev.filter((grupo) => grupo.id !== grupoId))

    if (grupoActivo === grupoId) {
      setGrupoActivo("default")
    }

    toast({
      title: "Grupo eliminado",
      description: "Los items han sido movidos al grupo general",
    })
  }

  const actualizarGrupo = (grupoId: string, datos: any) => {
    setGrupos((prev) =>
      prev.map((grupo) =>
        grupo.id === grupoId
          ? {
              ...grupo,
              ...datos,
              imagenUrl: datos.imagen ? URL.createObjectURL(datos.imagen) : grupo.imagenUrl,
            }
          : grupo,
      ),
    )

    // Guardar inmediatamente para asegurar que la imagen se procese
    setTimeout(() => {
      guardarSesionAutomatica()
    }, 500)
  }

  const calcularTotal = () => {
    return items.reduce((total, item) => total + (item.precio_total || 0), 0)
  }

  const guardarCotizacion = async () => {
    if (items.length === 0) {
      toast({
        title: "Error",
        description: "No hay items en la cotización",
        variant: "destructive",
      })
      return
    }

    if (!cliente) {
      toast({
        title: "Error",
        description: "Debe seleccionar un cliente",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)

      const cotizacionData = {
        cliente_id: cliente._id,
        items: items,
        grupos: grupos,
        subtotal: calcularTotal(),
        iva: calcularTotal() * 0.15,
        total: calcularTotal() * 1.15,
        tipo: tipoCotizacion || "mixta",
        estado: "borrador",
      }

      console.log("📤 Enviando cotización:", cotizacionData)

      const response = await fetch("/api/cotizaciones", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cotizacionData),
      })

      const result = await response.json()

      if (response.ok && result.success) {
        toast({
          title: "¡Cotización guardada exitosamente!",
          description: `Cotización ${result.cotizacion.numero} creada. Redirigiendo a vista previa...`,
        })

        limpiarSesion()

        // Redirigir a la vista previa después de 2 segundos
        setTimeout(() => {
          window.location.href = `/dashboard/cotizaciones/ver/${result.cotizacion._id}`
        }, 2000)
      } else {
        throw new Error(result.details || result.error || "Error desconocido")
      }
    } catch (error) {
      console.error("❌ Error guardando cotización:", error)
      toast({
        title: "Error",
        description: `No se pudo guardar la cotización: ${error.message}`,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const itemsGrupoActivo = items.filter(
    (item) => item.grupoId === grupoActivo || (!item.grupoId && grupoActivo === "default"),
  )

  return (
    <div className="space-y-6">
      {/* Header con Cliente y Sesión */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Nueva Cotización</CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Tipo: {tipoCotizacion ? tipoCotizacion.charAt(0).toUpperCase() + tipoCotizacion.slice(1) : "Mixta"}
              </p>

              {/* Indicadores de sesión */}
              <div className="flex gap-2 mt-2">
                {sesionInfo && (
                  <Badge variant="outline">Última sesión: {new Date(sesionInfo.timestamp).toLocaleTimeString()}</Badge>
                )}
                {autoGuardado && (
                  <Badge className="bg-green-500">
                    <Save className="w-3 h-3 mr-1" />
                    Guardado
                  </Badge>
                )}
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={guardarSesionManual} disabled={guardando}>
                <Save className="w-4 h-4 mr-2" />
                {guardando ? "Guardando..." : "Guardar Sesión"}
              </Button>
              <ClienteSelector cliente={cliente} onClienteSeleccionado={setCliente} />
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Alerta de error de sesión */}
      {errorSesion && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error de sesión</AlertTitle>
          <AlertDescription>
            {errorSesion}
            <Button variant="link" className="p-0 h-auto text-white underline ml-2" onClick={guardarSesionManual}>
              Intentar guardar manualmente
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Gestión de Grupos */}
      <GruposManager
        grupos={grupos}
        grupoActivo={grupoActivo}
        items={items}
        onGrupoSeleccionado={setGrupoActivo}
        onCrearGrupo={crearGrupo}
        onEliminarGrupo={eliminarGrupo}
        onActualizarGrupo={actualizarGrupo}
      />

      {/* Panel de Agregar Items - TODOS LOS TIPOS */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Plus className="w-5 h-5 mr-2" />
            Agregar Items a la Cotización
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Productos */}
            <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-blue-500">
              <CardContent className="p-6 text-center" onClick={() => setModalSeleccionProducto(true)}>
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Package className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Productos</h3>
                <p className="text-sm text-gray-600">Cotizar productos del catálogo</p>
                <Badge className="mt-2">Usa Materiales</Badge>
              </CardContent>
            </Card>

            {/* Reparaciones */}
            <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-green-500">
              <CardContent className="p-6 text-center" onClick={() => setModalReparacion(true)}>
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wrench className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Reparaciones</h3>
                <p className="text-sm text-gray-600">Servicios de reparación</p>
                <Badge variant="secondary" className="mt-2">
                  Precio Fijo
                </Badge>
              </CardContent>
            </Card>

            {/* Vidrio Templado */}
            <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-purple-500">
              <CardContent className="p-6 text-center" onClick={() => setModalVidrioTemplado(true)}>
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <GlassWater className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Vidrio Templado</h3>
                <p className="text-sm text-gray-600">Barandales, puertas, divisiones</p>
                <Badge variant="secondary" className="mt-2">
                  Calculado
                </Badge>
              </CardContent>
            </Card>

            {/* Cotización Libre */}
            <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-orange-500">
              <CardContent className="p-6 text-center" onClick={() => setModalLibre(true)}>
                <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Cotización Libre</h3>
                <p className="text-sm text-gray-600">Items personalizados</p>
                <Badge variant="secondary" className="mt-2">
                  Manual
                </Badge>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Items del Grupo Activo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <ShoppingCart className="w-5 h-5 mr-2" />
              Items en {grupos.find((g) => g.id === grupoActivo)?.nombre} ({itemsGrupoActivo.length})
            </div>
            {items.length > 0 && (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => cargarSesionGuardada()}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Recargar
                </Button>
                <Button variant="outline" size="sm" onClick={limpiarSesion}>
                  Limpiar Todo
                </Button>
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {itemsGrupoActivo.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No hay items en este grupo</p>
              <p className="text-sm mt-2">Agrega items usando los botones de arriba</p>
            </div>
          ) : (
            <div className="space-y-4">
              {itemsGrupoActivo.map((item, index) => (
                <Card key={item.id} className="border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline">#{index + 1}</Badge>
                          <Badge>{item.tipo || "Item"}</Badge>
                          <h3 className="font-semibold">{item.nombre || item.descripcion}</h3>
                        </div>

                        {item.descripcion && item.nombre !== item.descripcion && (
                          <p className="text-sm text-gray-600 mb-2">{item.descripcion}</p>
                        )}

                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                          {/* Cantidad editable */}
                          <div>
                            <span className="font-medium">Cantidad:</span>
                            <div className="flex items-center gap-1 mt-1">
                              <Input
                                type="number"
                                min="1"
                                value={item.cantidad || 1}
                                onChange={(e) => actualizarCantidadItem(item.id, Number(e.target.value))}
                                className="w-16 h-8 text-xs"
                              />
                            </div>
                          </div>

                          {item.dimensiones && (
                            <div>
                              <span className="font-medium">Dimensiones:</span>
                              <p>
                                {item.dimensiones.ancho}x{item.dimensiones.alto}
                                {item.dimensiones.area ? ` (${item.dimensiones.area.toFixed(2)}m²)` : ""}
                              </p>
                            </div>
                          )}

                          {item.precio_unitario && (
                            <div>
                              <span className="font-medium">Precio Unit:</span>
                              <p>L {item.precio_unitario.toLocaleString()}</p>
                            </div>
                          )}

                          <div>
                            <span className="font-medium">Total:</span>
                            <p className="font-bold text-green-600">L {(item.precio_total || 0).toLocaleString()}</p>
                          </div>

                          {/* Selector de grupo */}
                          <div>
                            <span className="font-medium text-xs">Grupo:</span>
                            <select
                              value={item.grupoId || "default"}
                              onChange={(e) => moverItemAGrupo(item.id, e.target.value)}
                              className="text-xs border rounded px-2 py-1 w-full mt-1"
                            >
                              {grupos.map((grupo) => (
                                <option key={grupo.id} value={grupo.id}>
                                  {grupo.nombre}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        {item.materiales && item.materiales.length > 0 && (
                          <div className="mt-3">
                            <p className="text-sm font-medium mb-1">Materiales:</p>
                            <div className="flex flex-wrap gap-1">
                              {item.materiales.slice(0, 3).map((material: any, idx: number) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {material.nombre}
                                </Badge>
                              ))}
                              {item.materiales.length > 3 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{item.materiales.length - 3} más
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}

                        {item.notas && (
                          <div className="mt-2">
                            <p className="text-sm font-medium">Notas:</p>
                            <p className="text-sm text-gray-600">{item.notas}</p>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2 ml-4">
                        <Button variant="ghost" size="sm" onClick={() => editarItem(item.id)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => eliminarItem(item.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resumen y Acciones */}
      {items.length > 0 && (
        <ResumenCotizacion
          items={items}
          grupos={grupos}
          cliente={cliente}
          onGuardar={guardarCotizacion}
          onLimpiar={limpiarSesion}
        />
      )}

      {/* Modales */}
      <SeleccionarProductoModal
        isOpen={modalSeleccionProducto}
        onClose={() => setModalSeleccionProducto(false)}
        productos={productos}
        onProductoSeleccionado={(producto) => {
          setProductoSeleccionado(producto)
          setModalSeleccionProducto(false)
          setModalProducto(true)
        }}
      />

      <CotizarProductoModal
        isOpen={modalProducto}
        onClose={() => {
          setModalProducto(false)
          setProductoSeleccionado(null)
          setItemEditando(null)
        }}
        producto={productoSeleccionado}
        itemEditando={itemEditando}
        onAgregarCotizacion={agregarItem}
      />

      <CotizarReparacionModal
        isOpen={modalReparacion}
        onClose={() => {
          setModalReparacion(false)
          setItemEditando(null)
        }}
        itemEditando={itemEditando}
        onAgregarItem={agregarItem}
      />

      <CotizarVidrioTempladoModal
        isOpen={modalVidrioTemplado}
        onClose={() => {
          setModalVidrioTemplado(false)
          setItemEditando(null)
        }}
        itemEditando={itemEditando}
        onAgregarItem={agregarItem}
      />

      <CotizacionLibreModal
        isOpen={modalLibre}
        onClose={() => {
          setModalLibre(false)
          setItemEditando(null)
        }}
        itemEditando={itemEditando}
        onAgregarItem={agregarItem}
      />
    </div>
  )
}
