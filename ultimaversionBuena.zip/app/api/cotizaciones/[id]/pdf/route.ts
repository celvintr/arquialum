import { type NextRequest, NextResponse } from "next/server"
import { connectDB } from "@/lib/mongodb"
import Cotizacion from "@/lib/models/Cotizacion"
import puppeteer from "puppeteer"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()

    const cotizacion = await Cotizacion.findById(params.id)

    if (!cotizacion) {
      return NextResponse.json({ success: false, error: "Cotización no encontrada" }, { status: 404 })
    }

    // Generar HTML para el PDF
    const htmlContent = generateCotizacionHTML(cotizacion)

    // Configurar Puppeteer
    const browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    })

    const page = await browser.newPage()

    // Configurar el contenido HTML
    await page.setContent(htmlContent, {
      waitUntil: "networkidle0",
    })

    // Generar PDF con configuraciones profesionales
    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: {
        top: "20mm",
        right: "15mm",
        bottom: "20mm",
        left: "15mm",
      },
      displayHeaderFooter: true,
      headerTemplate: `
        <div style="font-size: 10px; width: 100%; text-align: center; color: #666;">
          <span>ArquiAlum Honduras - Cotización ${cotizacion.numero}</span>
        </div>
      `,
      footerTemplate: `
        <div style="font-size: 10px; width: 100%; text-align: center; color: #666;">
          <span>Página <span class="pageNumber"></span> de <span class="totalPages"></span> - Generado el ${new Date().toLocaleDateString("es-HN")}</span>
        </div>
      `,
    })

    await browser.close()

    // Retornar el PDF
    return new NextResponse(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="Cotizacion-${cotizacion.numero}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generando PDF:", error)
    return NextResponse.json({ success: false, error: "Error generando PDF" }, { status: 500 })
  }
}

function generateCotizacionHTML(cotizacion: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Cotización ${cotizacion.numero}</title>
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Arial', sans-serif;
          font-size: 12px;
          line-height: 1.4;
          color: #333;
        }
        
        .container {
          max-width: 100%;
          margin: 0 auto;
          padding: 20px;
        }
        
        .header {
          border: 4px solid #3b82f6;
          padding: 20px;
          margin-bottom: 20px;
          page-break-inside: avoid;
        }
        
        .header-grid {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: 20px;
          align-items: start;
        }
        
        .company-info {
          display: flex;
          align-items: center;
          gap: 15px;
        }
        
        .logo-placeholder {
          width: 80px;
          height: 80px;
          background-color: #f3f4f6;
          border: 1px solid #d1d5db;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          color: #6b7280;
        }
        
        .company-details h1 {
          font-size: 18px;
          font-weight: bold;
          color: #1f2937;
          margin-bottom: 5px;
        }
        
        .company-details p {
          font-size: 10px;
          color: #6b7280;
          margin-bottom: 2px;
        }
        
        .cotizacion-info {
          background-color: #f3f4f6;
          padding: 15px;
          border-radius: 8px;
          text-align: right;
        }
        
        .cotizacion-info h2 {
          font-size: 16px;
          font-weight: bold;
          margin-bottom: 5px;
        }
        
        .social-media {
          background-color: #f3f4f6;
          padding: 10px;
          text-align: center;
          margin-bottom: 20px;
          font-size: 10px;
        }
        
        .separator {
          height: 2px;
          background-color: #ef4444;
          margin: 20px 0;
        }
        
        .client-vendor-info {
          border-top: 1px solid #d1d5db;
          border-bottom: 1px solid #d1d5db;
          padding: 15px 0;
          margin-bottom: 20px;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 30px;
        }
        
        .info-section h3 {
          font-weight: bold;
          margin-bottom: 8px;
          font-size: 12px;
        }
        
        .info-section p {
          font-size: 10px;
          margin-bottom: 3px;
        }
        
        .separator-blue {
          height: 2px;
          background-color: #3b82f6;
          margin: 20px 0;
        }
        
        .grupo {
          margin-bottom: 30px;
          page-break-inside: avoid;
        }
        
        .grupo-header {
          background-color: #f3f4f6;
          padding: 15px;
          text-align: center;
          margin-bottom: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 15px;
        }
        
        .grupo-imagen {
          max-width: 120px;
          height: 60px;
          object-fit: cover;
          border-radius: 4px;
        }
        
        .grupo-header h5 {
          font-size: 14px;
          font-weight: bold;
        }
        
        .productos-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        
        .productos-table th,
        .productos-table td {
          border: 1px solid #d1d5db;
          padding: 8px;
          text-align: left;
          vertical-align: top;
        }
        
        .productos-table th {
          background-color: #f3f4f6;
          font-weight: bold;
          font-size: 10px;
        }
        
        .productos-table td {
          font-size: 9px;
        }
        
        .producto-imagen {
          max-width: 60px;
          height: 40px;
          object-fit: cover;
          margin: 0 auto;
          display: block;
        }
        
        .imagen-placeholder {
          width: 60px;
          height: 40px;
          background-color: #f3f4f6;
          border: 1px solid #d1d5db;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 8px;
          color: #6b7280;
          margin: 0 auto;
        }
        
        .producto-details {
          line-height: 1.3;
        }
        
        .producto-details p {
          margin-bottom: 3px;
        }
        
        .producto-nombre {
          font-weight: bold;
          font-size: 10px;
        }
        
        .resumen-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        
        .resumen-table td {
          border: 1px solid #d1d5db;
          padding: 8px;
          font-size: 10px;
        }
        
        .resumen-table .total-row {
          background-color: #f3f4f6;
          font-weight: bold;
          font-size: 12px;
        }
        
        .resumen-table .total-amount {
          color: #059669;
          font-weight: bold;
        }
        
        .terminos {
          background-color: #f3f4f6;
          padding: 20px;
          border-radius: 8px;
          margin-bottom: 20px;
          page-break-inside: avoid;
        }
        
        .terminos h4 {
          text-align: center;
          font-size: 14px;
          font-weight: bold;
          margin-bottom: 15px;
        }
        
        .terminos-content {
          font-size: 9px;
          line-height: 1.4;
        }
        
        .terminos-section {
          margin-bottom: 12px;
        }
        
        .terminos-section p {
          font-weight: bold;
          margin-bottom: 5px;
        }
        
        .terminos-section ul,
        .terminos-section ol {
          margin-left: 15px;
          margin-bottom: 5px;
        }
        
        .terminos-section li {
          margin-bottom: 2px;
        }
        
        .terminos-footer {
          text-align: center;
          margin-top: 15px;
          font-size: 10px;
        }
        
        .terminos-footer p {
          margin-bottom: 5px;
        }
        
        .firmas {
          display: flex;
          justify-content: space-between;
          margin-top: 40px;
          page-break-inside: avoid;
        }
        
        .firma {
          text-align: center;
          width: 200px;
        }
        
        .firma-linea {
          border-top: 1px solid #6b7280;
          margin-bottom: 5px;
        }
        
        .firma p {
          font-size: 10px;
          font-weight: bold;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        
        @media print {
          .page-break {
            page-break-before: always;
          }
          
          .no-break {
            page-break-inside: avoid;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <!-- Header -->
        <div class="header">
          <div class="header-grid">
            <div class="company-info">
              <div class="logo-placeholder">LOGO</div>
              <div class="company-details">
                <h1>ArquiAlum Honduras</h1>
                <p>Colonia Kennedy, Bloque M, Casa 2516</p>
                <p>Tegucigalpa, Honduras</p>
                <p>RTN: 08019016832627</p>
                <p>Tel: +504 9999-9999 / Email: info@arquialum.hn</p>
              </div>
            </div>
            <div class="cotizacion-info">
              <h2>Cotización</h2>
              <p>#${cotizacion.numero}</p>
              <p>Fecha: ${new Date(cotizacion.fechaCreacion).toLocaleDateString("es-HN")}</p>
              <p>Válido hasta: ${new Date(cotizacion.fechaVencimiento).toLocaleDateString("es-HN")}</p>
            </div>
          </div>
        </div>

        <!-- Redes Sociales -->
        <div class="social-media">
          <p>
            <strong>Redes Sociales:</strong>
            📘 ArquiAlumHonduras | 🎵 @arqui.alum | 📷 arquialum.hn | 🌐 www.arquialumhn.com
          </p>
        </div>

        <div class="separator"></div>

        <!-- Información Cliente y Vendedor -->
        <div class="client-vendor-info">
          <div class="info-section">
            <h3>INFORMACIÓN DEL CLIENTE</h3>
            <p><strong>Nombre:</strong> ${cotizacion.cliente.nombre}</p>
            <p><strong>RTN:</strong> ${cotizacion.cliente.rtn || "N/A"}</p>
            <p><strong>Teléfono:</strong> ${cotizacion.cliente.telefono || "N/A"}</p>
            <p><strong>Dirección:</strong> ${cotizacion.cliente.direccion || "N/A"}</p>
          </div>
          <div class="info-section">
            <h3>INFORMACIÓN DEL VENDEDOR</h3>
            <p><strong>Encargada:</strong> María González</p>
            <p><strong>Asesor de Venta:</strong> ${cotizacion.vendedor.nombre}</p>
            <p><strong>Teléfono:</strong> +504 9999-9999</p>
            <p><strong>Email:</strong> ${cotizacion.vendedor.email}</p>
          </div>
        </div>

        <div class="separator-blue"></div>

        <!-- Productos por Grupos -->
        ${cotizacion.grupos
          .map((grupo: any) => {
            const itemsDelGrupo = cotizacion.items.filter((item: any) => item.grupoId === grupo.id)
            if (itemsDelGrupo.length === 0) return ""

            return `
            <div class="grupo">
              <div class="grupo-header">
                ${grupo.imagenUrl ? `<img src="${grupo.imagenUrl}" alt="${grupo.nombre}" class="grupo-imagen">` : ""}
                <h5>${grupo.nombre}</h5>
              </div>
              
              <table class="productos-table">
                <thead>
                  <tr>
                    <th style="width: 15%;">Gráfico</th>
                    <th style="width: 50%;">Producto y Detalles</th>
                    <th style="width: 17.5%;">Precio Unitario</th>
                    <th style="width: 17.5%;">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsDelGrupo
                    .map(
                      (item: any) => `
                    <tr>
                      <td class="text-center">
                        ${
                          item.imagenUrl
                            ? `<img src="${item.imagenUrl}" alt="${item.nombre}" class="producto-imagen">`
                            : '<div class="imagen-placeholder">Sin imagen</div>'
                        }
                      </td>
                      <td>
                        <div class="producto-details">
                          <p class="producto-nombre">${item.nombre}</p>
                          <p>${item.descripcion}</p>
                          ${item.dimensiones ? `<p>Dimensiones: ${item.dimensiones.ancho || "N/A"} x ${item.dimensiones.alto || "N/A"}</p>` : ""}
                          ${item.especificaciones?.color ? `<p>Color: ${item.especificaciones.color}</p>` : ""}
                          ${item.especificaciones?.material ? `<p>Material: ${item.especificaciones.material}</p>` : ""}
                          <p><strong>Cantidad: ${item.cantidad}</strong></p>
                        </div>
                      </td>
                      <td class="text-center">
                        <strong>L ${item.precio_unitario.toLocaleString("es-HN")}</strong>
                      </td>
                      <td class="text-center">
                        <strong>L ${item.precio_total.toLocaleString("es-HN")}</strong>
                      </td>
                    </tr>
                  `,
                    )
                    .join("")}
                </tbody>
              </table>
            </div>
          `
          })
          .join("")}

        <!-- Resumen Financiero -->
        <table class="resumen-table">
          <tbody>
            <tr>
              <td colspan="3" class="text-right"><strong>Productos Cotizados</strong></td>
              <td class="text-center">${cotizacion.items.reduce((sum: number, item: any) => sum + item.cantidad, 0)}</td>
            </tr>
            <tr>
              <td colspan="3" class="text-right"><strong>Subtotal</strong></td>
              <td class="text-center">L ${cotizacion.subtotal.toLocaleString("es-HN")}</td>
            </tr>
            ${
              cotizacion.descuento > 0
                ? `
              <tr>
                <td colspan="3" class="text-right"><strong>Descuento</strong></td>
                <td class="text-center" style="color: #dc2626;">-L ${cotizacion.descuento.toLocaleString("es-HN")}</td>
              </tr>
            `
                : ""
            }
            <tr>
              <td colspan="3" class="text-right"><strong>IVA (15%)</strong></td>
              <td class="text-center">L ${cotizacion.iva.toLocaleString("es-HN")}</td>
            </tr>
            <tr class="total-row">
              <td colspan="3" class="text-right"><strong>TOTAL</strong></td>
              <td class="text-center total-amount">L ${cotizacion.total.toLocaleString("es-HN")}</td>
            </tr>
            ${
              cotizacion.pagos_realizados && cotizacion.pagos_realizados > 0
                ? `
              <tr>
                <td colspan="3" class="text-right"><strong>Pagos Realizados</strong></td>
                <td class="text-center" style="color: #059669;">L ${cotizacion.pagos_realizados.toLocaleString("es-HN")}</td>
              </tr>
              <tr style="background-color: #fef3c7;">
                <td colspan="3" class="text-right"><strong>Saldo Pendiente</strong></td>
                <td class="text-center" style="color: #d97706; font-weight: bold;">L ${(cotizacion.saldo_pendiente || 0).toLocaleString("es-HN")}</td>
              </tr>
            `
                : ""
            }
          </tbody>
        </table>

        <!-- Términos y Condiciones -->
        <div class="terminos">
          <h4>Términos y Condiciones</h4>
          <div class="terminos-content">
            <div class="terminos-section">
              <p>1. Condiciones de Pago</p>
              <ul>
                <li>Anticipo: 70% - L ${(cotizacion.total * 0.7).toLocaleString("es-HN")}</li>
                <li>Pago Restante: 30% el día de instalación - L ${(cotizacion.total * 0.3).toLocaleString("es-HN")}</li>
              </ul>
            </div>

            <div class="terminos-section">
              <p>2. Tiempo de Entrega</p>
              <ul>
                <li>Plazo: 15 días hábiles desde la confirmación del pedido.</li>
              </ul>
            </div>

            <div class="terminos-section">
              <p>3. Garantía</p>
              <ul>
                <li>Período de Garantía: 3 meses por fabricación.</li>
                <li><strong>Exclusiones:</strong></li>
              </ul>
              <ol>
                <li>La garantía no incluye fracturas de vidrio por accidentes posteriores a la instalación.</li>
                <li>Precio incluye traslado dentro del casco urbano; fuera de este se cobrará flete.</li>
                <li>La cotización no cubre la desinstalación de ventanas existentes; este servicio se cobrará aparte.</li>
                <li>Arquialum no se hace responsable si los boquetes de puertas y ventanas se encuentran con descuadres mayores a 5 mm o desplomes en la pared.</li>
              </ol>
            </div>

            <div class="terminos-section">
              <p>4. Otros</p>
              <ul>
                <li>Sellado de puertas y ventanas por dentro y por fuera con silicona de alta calidad.</li>
                <li>Todos los perfiles de PVC llevan refuerzo metálico.</li>
                <li>Todas las puertas y ventanas llevan malla mosquitero.</li>
              </ul>
            </div>

            <div class="terminos-footer">
              <p><strong>Su preferencia nos motiva a seguir mejorando calidad. Estamos a su disposición para cualquier consulta o información adicional.</strong></p>
              <p><strong>Gracias por elegirnos.</strong></p>
              <p><strong>Duración de la Cotización Aprobada:</strong> 30 días</p>
            </div>
          </div>
        </div>

        <!-- Firmas -->
        <div class="firmas">
          <div class="firma">
            <div class="firma-linea"></div>
            <p>Firma del Cliente</p>
          </div>
          <div class="firma">
            <div class="firma-linea"></div>
            <p>Firma del Vendedor</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `
}
