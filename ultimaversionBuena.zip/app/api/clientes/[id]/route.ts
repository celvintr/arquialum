import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const { id } = params

    const cliente = await db.collection("clientes").findOne({ _id: id })

    if (!cliente) {
      return NextResponse.json({ success: false, error: "Cliente no encontrado" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      cliente,
    })
  } catch (error) {
    console.error("❌ Error obteniendo cliente:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const { id } = params
    const body = await request.json()

    console.log("🔄 Actualizando cliente:", id, body)

    // Validar datos requeridos
    if (!body.nombre || !body.email) {
      return NextResponse.json({ success: false, error: "Nombre y email son requeridos" }, { status: 400 })
    }

    // Verificar si el email ya existe en otro cliente
    const existeEmail = await db.collection("clientes").findOne({
      email: body.email,
      _id: { $ne: id },
    })

    if (existeEmail) {
      return NextResponse.json({ success: false, error: "El email ya está registrado" }, { status: 400 })
    }

    const result = await db.collection("clientes").updateOne(
      { _id: id },
      {
        $set: {
          ...body,
          updated_at: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ success: false, error: "Cliente no encontrado" }, { status: 404 })
    }

    console.log("✅ Cliente actualizado")

    return NextResponse.json({
      success: true,
      message: "Cliente actualizado exitosamente",
    })
  } catch (error) {
    console.error("❌ Error actualizando cliente:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error al actualizar cliente",
        details: error.message,
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const { id } = params

    console.log("🗑️ Eliminando cliente:", id)

    const result = await db.collection("clientes").deleteOne({ _id: id })

    if (result.deletedCount === 0) {
      return NextResponse.json({ success: false, error: "Cliente no encontrado" }, { status: 404 })
    }

    console.log("✅ Cliente eliminado")

    return NextResponse.json({
      success: true,
      message: "Cliente eliminado exitosamente",
    })
  } catch (error) {
    console.error("❌ Error eliminando cliente:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error al eliminar cliente",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
