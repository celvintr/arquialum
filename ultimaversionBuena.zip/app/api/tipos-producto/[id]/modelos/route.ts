import { NextResponse } from "next/server"
import dbConnect from "@/lib/mongodb"
import TipoProductoModelo from "@/lib/models/TipoProductoModelo"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    await dbConnect()

    const modelos = await TipoProductoModelo.find({
      tipo_producto_id: params.id,
      isActive: true,
    }).sort({ nombre: 1 })

    return NextResponse.json({
      success: true,
      modelos: modelos.map((modelo) => ({
        _id: modelo._id.toString(),
        nombre: modelo.nombre,
        descripcion: modelo.descripcion,
        codigo: modelo.codigo,
      })),
    })
  } catch (error) {
    console.error("Error obteniendo modelos:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error interno del servidor",
      },
      { status: 500 },
    )
  }
}
