import { type NextRequest, NextResponse } from "next/server"
import puppeteer from "puppeteer"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { db } = await connectToDatabase()
    const { id } = params

    // Obtener datos de la orden
    const orden = await db.collection("ordenes-trabajo").findOne({
      _id: new ObjectId(id),
    })

    if (!orden) {
      return NextResponse.json({ success: false, error: "Orden no encontrada" }, { status: 404 })
    }

    // Generar HTML para el PDF
    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Hoja de Producción - ${orden.numero}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; font-size: 12px; line-height: 1.4; }
        .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header p { font-size: 14px; opacity: 0.9; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; padding: 20px; }
        .info-card { border: 1px solid #e5e7eb; padding: 15px; border-radius: 8px; }
        .info-card h3 { font-size: 10px; color: #6b7280; margin-bottom: 8px; }
        .info-card p { font-size: 14px; font-weight: bold; }
        .materials-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        .materials-table th, .materials-table td { border: 1px solid #d1d5db; padding: 8px; text-align: left; }
        .materials-table th { background: #f9fafb; font-weight: bold; font-size: 10px; }
        .product-section { margin: 20px 0; border: 2px solid #bfdbfe; border-radius: 8px; }
        .product-header { background: #eff6ff; padding: 15px; border-bottom: 1px solid #bfdbfe; }
        .product-content { padding: 15px; }
        .specs-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px; }
        .process-step { display: flex; align-items: center; gap: 10px; padding: 8px; background: #f9fafb; margin: 5px 0; border-radius: 4px; }
        .step-number { width: 20px; height: 20px; background: #2563eb; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; }
        .signature-section { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-top: 30px; }
        .signature-line { border-top: 1px solid #374151; width: 200px; margin-bottom: 5px; }
        @page { margin: 15mm; }
        @media print { .no-print { display: none; } }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>HOJA DE PRODUCCIÓN</h1>
        <p>ArquiAlum Honduras - Sistema de Fabricación</p>
        <div style="margin-top: 15px; background: white; color: #2563eb; padding: 10px; border-radius: 8px; display: inline-block;">
          <strong>Orden: ${orden.numero}</strong> | Cotización: ${orden.cotizacion_numero}
        </div>
      </div>

      <div class="info-grid">
        <div class="info-card">
          <h3>CLIENTE</h3>
          <p>${orden.cliente_nombre}</p>
          <p style="font-size: 12px; font-weight: normal;">${orden.cliente_telefono || ""}</p>
        </div>
        <div class="info-card">
          <h3>FECHA INICIO</h3>
          <p>${new Date(orden.fecha_inicio).toLocaleDateString("es-HN")}</p>
        </div>
        <div class="info-card">
          <h3>FECHA ENTREGA</h3>
          <p style="color: #dc2626;">${new Date(orden.fecha_estimada_fin).toLocaleDateString("es-HN")}</p>
        </div>
      </div>

      ${
        orden.items_cotizacion
          ?.map(
            (producto, index) => `
        <div class="product-section">
          <div class="product-header">
            <h2 style="font-size: 18px; margin-bottom: 5px;">${index + 1}. ${producto.nombre}</h2>
            <p style="color: #6b7280;">${producto.descripcion}</p>
            <p style="margin-top: 5px;"><strong>Cantidad: ${producto.cantidad}</strong></p>
          </div>
          <div class="product-content">
            <div class="specs-grid">
              <div>
                <h4 style="margin-bottom: 10px;">Especificaciones Técnicas</h4>
                ${
                  producto.especificaciones
                    ? Object.entries(producto.especificaciones)
                        .map(
                          ([key, value]) => `
                  <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="color: #6b7280;">${key.replace(/_/g, " ")}:</span>
                    <span style="font-weight: bold;">${value}</span>
                  </div>
                `,
                        )
                        .join("")
                    : ""
                }
              </div>
              ${
                producto.dimensiones
                  ? `
                <div>
                  <h4 style="margin-bottom: 10px;">Dimensiones</h4>
                  <div style="background: #f9fafb; padding: 15px; border-radius: 8px; text-align: center;">
                    <div style="font-size: 20px; font-weight: bold; color: #2563eb;">
                      ${producto.dimensiones.ancho} x ${producto.dimensiones.alto}
                    </div>
                    <div style="font-size: 10px; color: #6b7280;">cm (Ancho x Alto)</div>
                    <div style="font-size: 14px; font-weight: bold; margin-top: 8px;">
                      Área: ${producto.dimensiones.area?.toFixed(2)} m²
                    </div>
                  </div>
                </div>
              `
                  : ""
              }
            </div>

            ${
              producto.materiales_calculados && producto.materiales_calculados.length > 0
                ? `
              <h4 style="margin: 15px 0 10px 0;">Materiales Específicos</h4>
              <table class="materials-table">
                <thead>
                  <tr>
                    <th>Material</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th>Usado</th>
                    <th>Notas</th>
                  </tr>
                </thead>
                <tbody>
                  ${producto.materiales_calculados
                    .map(
                      (material) => `
                    <tr>
                      <td>
                        <div style="font-weight: bold;">${material.nombre}</div>
                        <div style="font-size: 10px; color: #6b7280;">${material.categoria}</div>
                      </td>
                      <td style="text-align: center; font-weight: bold;">${material.cantidad.toFixed(2)}</td>
                      <td style="text-align: center;">${material.unidad}</td>
                      <td style="text-align: center;">_______</td>
                      <td>_________________</td>
                    </tr>
                  `,
                    )
                    .join("")}
                </tbody>
              </table>
            `
                : ""
            }

            <h4 style="margin: 15px 0 10px 0;">Proceso de Fabricación</h4>
            ${[
              "Corte de perfiles según medidas especificadas",
              "Preparación y limpieza de materiales",
              "Ensamble de marco principal",
              "Instalación de herrajes y accesorios",
              "Colocación de vidrio con sellado",
              "Control de calidad y ajustes finales",
              "Empaque y preparación para entrega",
            ]
              .map(
                (paso, pasoIndex) => `
              <div class="process-step">
                <div class="step-number">${pasoIndex + 1}</div>
                <span style="flex: 1;">${paso}</span>
                <span style="font-size: 10px; color: #6b7280;">Responsable: _______________</span>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      `,
          )
          .join("") || ""
      }

      <div style="margin-top: 30px; border: 1px solid #fbbf24; background: #fffbeb; padding: 20px; border-radius: 8px;">
        <h3 style="margin-bottom: 15px;">Control de Calidad</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
          <div>
            <h4 style="margin-bottom: 10px;">Verificaciones Obligatorias</h4>
            ${[
              "Medidas exactas según especificaciones",
              "Calidad de cortes y acabados",
              "Funcionamiento de herrajes",
              "Sellado correcto de vidrios",
              "Limpieza general del producto",
            ]
              .map(
                (item) => `
              <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                <div style="width: 15px; height: 15px; border: 2px solid #6b7280; border-radius: 3px;"></div>
                <span style="font-size: 11px;">${item}</span>
              </div>
            `,
              )
              .join("")}
          </div>
          <div class="signature-section">
            <div>
              <div class="signature-line"></div>
              <p style="font-weight: bold; font-size: 11px;">Supervisor de Producción</p>
              <p style="font-size: 10px; color: #6b7280;">Fecha: _______________</p>
            </div>
            <div>
              <div class="signature-line"></div>
              <p style="font-weight: bold; font-size: 11px;">Control de Calidad</p>
              <p style="font-size: 10px; color: #6b7280;">Fecha: _______________</p>
            </div>
          </div>
        </div>
      </div>
    </body>
    </html>
    `

    // Generar PDF con Puppeteer
    const browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    })

    const page = await browser.newPage()
    await page.setContent(htmlContent, { waitUntil: "networkidle0" })

    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: { top: "10mm", right: "10mm", bottom: "10mm", left: "10mm" },
      displayHeaderFooter: true,
      headerTemplate: `<div style="font-size: 10px; width: 100%; text-align: center; color: #666;">ArquiAlum Honduras - Hoja de Producción ${orden.numero}</div>`,
      footerTemplate: `<div style="font-size: 10px; width: 100%; text-align: center; color: #666;">Página <span class="pageNumber"></span> de <span class="totalPages"></span></div>`,
    })

    await browser.close()

    return new NextResponse(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="Produccion-${orden.numero}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generando PDF de producción:", error)
    return NextResponse.json({ success: false, error: "Error interno del servidor" }, { status: 500 })
  }
}
