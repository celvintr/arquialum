"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Eye, CreditCard, DollarSign, TrendingUp, Calendar } from "lucide-react"
import { toast } from "sonner"

interface Pago {
  _id: string
  numero: string
  factura_id: string
  orden_trabajo_id: string
  monto: number
  metodo_pago: string
  fecha: string
  estado: string
}

export default function PagosPage() {
  const [pagos, setPagos] = useState<Pago[]>([])
  const [loading, setLoading] = useState(true)
  const [showRegistrarModal, setShowRegistrarModal] = useState(false)
  const [facturaId, setFacturaId] = useState("")
  const [monto, setMonto] = useState("")
  const [metodoPago, setMetodoPago] = useState("")

  useEffect(() => {
    cargarPagos()
  }, [])

  const cargarPagos = async () => {
    try {
      const response = await fetch("/api/pagos")
      const data = await response.json()

      if (data.success) {
        setPagos(data.pagos)
      } else {
        toast.error("Error al cargar los pagos")
      }
    } catch (error) {
      console.error("Error cargando pagos:", error)
      toast.error("Error al cargar los pagos")
    } finally {
      setLoading(false)
    }
  }

  const registrarPago = async () => {
    if (!facturaId || !monto || !metodoPago) {
      toast.error("Completa todos los campos")
      return
    }

    try {
      const response = await fetch("/api/pagos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          factura_id: facturaId,
          monto: Number.parseFloat(monto),
          metodo_pago: metodoPago,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast.success("Pago registrado exitosamente")
        setShowRegistrarModal(false)
        setFacturaId("")
        setMonto("")
        setMetodoPago("")
        cargarPagos()
      } else {
        toast.error(data.error || "Error al registrar el pago")
      }
    } catch (error) {
      console.error("Error registrando pago:", error)
      toast.error("Error al registrar el pago")
    }
  }

  const getMetodoPagoBadge = (metodo: string) => {
    const metodos = {
      efectivo: { label: "Efectivo", variant: "default" as const },
      transferencia: { label: "Transferencia", variant: "secondary" as const },
      cheque: { label: "Cheque", variant: "outline" as const },
      tarjeta_credito: { label: "Tarjeta Crédito", variant: "default" as const },
      tarjeta_debito: { label: "Tarjeta Débito", variant: "secondary" as const },
    }

    const config = metodos[metodo] || metodos.efectivo

    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  const totalPagos = pagos.reduce((sum, p) => sum + p.monto, 0)
  const pagosHoy = pagos.filter((p) => {
    const fechaPago = new Date(p.fecha)
    const hoy = new Date()
    return fechaPago.toDateString() === hoy.toDateString()
  })
  const pagosMesActual = pagos.filter((p) => {
    const fechaPago = new Date(p.fecha)
    const hoy = new Date()
    return fechaPago.getMonth() === hoy.getMonth() && fechaPago.getFullYear() === hoy.getFullYear()
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">💳 Gestión de Pagos</h1>
          <p className="text-gray-600">Control de pagos y cuentas por cobrar</p>
        </div>
        <Dialog open={showRegistrarModal} onOpenChange={setShowRegistrarModal}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Registrar Pago
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Pago</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="factura">Factura</Label>
                <Input
                  id="factura"
                  placeholder="Número de factura"
                  value={facturaId}
                  onChange={(e) => setFacturaId(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="monto">Monto</Label>
                <Input
                  id="monto"
                  type="number"
                  placeholder="0.00"
                  value={monto}
                  onChange={(e) => setMonto(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="metodo">Método de Pago</Label>
                <Select value={metodoPago} onValueChange={setMetodoPago}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona el método" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="efectivo">Efectivo</SelectItem>
                    <SelectItem value="transferencia">Transferencia</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                    <SelectItem value="tarjeta_credito">Tarjeta de Crédito</SelectItem>
                    <SelectItem value="tarjeta_debito">Tarjeta de Débito</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Button onClick={registrarPago} className="flex-1">
                  Registrar Pago
                </Button>
                <Button variant="outline" onClick={() => setShowRegistrarModal(false)}>
                  Cancelar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Total Cobrado</p>
                <p className="text-2xl font-bold">L {totalPagos.toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100">Pagos Hoy</p>
                <p className="text-2xl font-bold">{pagosHoy.length}</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100">Promedio Pago</p>
                <p className="text-2xl font-bold">
                  L {pagos.length ? Math.round(totalPagos / pagos.length).toLocaleString() : 0}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100">Total Pagos</p>
                <p className="text-2xl font-bold">{pagos.length}</p>
              </div>
              <CreditCard className="w-8 h-8 text-orange-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabla de Pagos */}
      <Card>
        <CardHeader>
          <CardTitle>Historial de Pagos</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Número</TableHead>
                <TableHead>Factura</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Método</TableHead>
                <TableHead>Monto</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pagos.map((pago) => (
                <TableRow key={pago._id}>
                  <TableCell className="font-medium">{pago.numero}</TableCell>
                  <TableCell>{pago.orden_trabajo_id || pago.factura_id || "N/A"}</TableCell>
                  <TableCell>{new Date(pago.fecha).toLocaleDateString("es-HN")}</TableCell>
                  <TableCell>{getMetodoPagoBadge(pago.metodo_pago)}</TableCell>
                  <TableCell className="font-bold">L {pago.monto.toLocaleString("es-HN")}</TableCell>
                  <TableCell>
                    <Badge variant={pago.estado === "completado" ? "default" : "secondary"}>
                      {pago.estado === "completado" ? "Confirmado" : "Pendiente"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button size="sm" variant="outline">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
